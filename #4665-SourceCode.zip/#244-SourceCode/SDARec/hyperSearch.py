'''
this file is for hypersearching of models
'''
from recbole.trainer import HyperTuning
import argparse
from recbole.quick_start.quick_start import objective_function


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', '-m', type=str, default='DuoRec', help='name of models')
    parser.add_argument('--dataset', '-d', type=str, default='Amazon_Beauty', help='name of datasets')
    parser.add_argument('--config_files', type=str, default='seq.yaml', help='config files')
    args, _ = parser.parse_known_args()

    hp = HyperTuning(objective_function=objective_function, algo='exhaustive',
                     max_evals=100, params_file='./hyperSearch/hyperConfig.hyper', fixed_config_file_list=['./seq.yaml'])

    # run
    hp.run()
    # export result to the file
    hp.export_result(output_file='./hyperSearch/hyperResult.result')
    # print best parameters
    print('best params: ', hp.best_params)
    # print best result
    print('best result: ')
    print(hp.params2result[hp.params2str(hp.best_params)])