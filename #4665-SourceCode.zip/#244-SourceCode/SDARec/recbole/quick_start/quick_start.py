# @Time   : 2020/10/6
# @Author : Shanlei Mu
# @Email  : slmu@ruc.edu.cn

"""
recbole.quick_start
########################
"""
import logging
from logging import getLogger
import torch
from recbole.config import Config
from recbole.data import create_dataset, data_preparation
from recbole.utils import init_logger, get_model, get_trainer, init_seed
from recbole.utils.utils import set_color
import json
import numpy as np



def run_recbole(model=None, dataset=None, config_file_list=None, config_dict=None, saved=True):
    r""" A fast running api, which includes the complete process of
    training and testing a model on a specified dataset

    Args:
        model (str): model name
        dataset (str): dataset name
        config_file_list (list): config files used to modify experiment parameters
        config_dict (dict): parameters dictionary used to modify experiment parameters
        saved (bool): whether to save the model
    """
    # configurations initialization
    config = Config(model=model, dataset=dataset, config_file_list=config_file_list, config_dict=config_dict)
    init_seed(config['seed'], config['reproducibility'])

    # logger initialization
    init_logger(config)
    logger = getLogger()

    import os
    log_dir = os.path.dirname(logger.handlers[0].baseFilename)
    config['log_dir'] = log_dir
    cpu_num = 4 # 这里设置成你想运行的CPU个数
    os.environ["OMP_NUM_THREADS"] = str(cpu_num)  # noqa
    os.environ["MKL_NUM_THREADS"] = str(cpu_num) # noqa
    torch.set_num_threads(cpu_num )
    
    logger.info(config)

    # dataset filtering
    dataset = create_dataset(config)
    logger.info(dataset)

    ####################################### save the dataset for creating LLM's inputs ####################################
    #### 必须先保存map数据，去掉val 和 test 需要使用
    if config['dump_dataset']:
        base_path = config['base_path']

        item_id_token = dataset.field2id_token['item_id'].tolist()
        item_id_token_dict = {k: v for k, v in zip(range(len(item_id_token)) , item_id_token)} 
        user_id_token = dataset.field2id_token['user_id'].tolist() 
        user_id_token_dict = {k: v for k, v in zip(range(len(user_id_token)) , user_id_token)} 

        item_token_id_dict = dataset.field2token_id['item_id']
        user_token_id_dict = dataset.field2token_id['user_id']

        user_map_dict = {'id_token': user_id_token_dict, 'token_id': user_token_id_dict}
        item_map_dict = {'id_token': item_id_token_dict, 'token_id': item_token_id_dict}

        with open(base_path + f"data/{config['dataset']}/user_map.json", 'w') as file:
            json.dump(user_map_dict, file)
        with open(base_path + f"data/{config['dataset']}/item_map.json", 'w') as file:
            json.dump(item_map_dict, file)

    ####################################### 修改val test 数据集去掉伪造用户，防止指标出错 ####################################
    # data_preparation.py 
    ####################################### save the train dataset for creating LLM's inputs####################################

    # dataset splitting
    train_data, valid_data, test_data = data_preparation(config, dataset)

    ####################################### save the dataset for creating LLM's inputs####################################
    if config['dump_dataset']:
        # 获取用户交互记录，取train的滑窗target item记录
        mask = train_data.dataset.mask
        target_item = train_data.dataset.inter_feat.interaction['item_id'][train_data.dataset.target_index].numpy()
        interaction_user_seqs = np.array([train_data.dataset.inter_feat.interaction['item_id'].numpy()[interval].tolist() for interval in train_data.dataset.item_list_index])
        interaction_target_seqs_dict = {}
        for index, target_id in enumerate(target_item):
            all_index_same_id = np.where(target_item == target_id)[0]  # all index of a specific item id with self item
            all_seqs_same_target = interaction_user_seqs[all_index_same_id].tolist()
            if target_id not in interaction_target_seqs_dict.keys():
                interaction_target_seqs_dict[str(target_id)] = all_seqs_same_target

        interaction_dict = {'target_seqs': interaction_target_seqs_dict}

        with open(base_path + f"data/{config['dataset']}/interaction.json", 'w') as file:
            json.dump(interaction_dict, file)
    ##########################################################################
    # # model loading and initialization
    # init_seed(config['seed'], config['reproducibility'])
    # model = get_model(config['model'])(config, train_data).to(config['device'])
    # logger.info(model)

    # # trainer loading and initialization
    # trainer = get_trainer(config['MODEL_TYPE'], config['model'])(config, model)

    # # model training
    # best_valid_score, best_valid_result = trainer.fit(
    #     train_data, valid_data, test_data, saved=saved, show_progress=config['show_progress']
    # )

    # import numpy as np
    # import seaborn as sns
    # import matplotlib.pyplot as plt
    # from sklearn.decomposition import TruncatedSVD

    # embedding_matrix = model.item_embedding.weight[1:].cpu().detach().numpy()
    # svd = TruncatedSVD(n_components=2)
    # svd.fit(embedding_matrix)
    # comp_tr = np.transpose(svd.components_)
    # proj = np.dot(embedding_matrix, comp_tr)
    
    # cnt = {}
    # for i in dataset['item_id']:
    #     if i.item() in cnt:
    #         cnt[i.item()] += 1
    #     else:
    #         cnt[i.item()] = 1
    
    # freq = np.zeros(embedding_matrix.shape[0])
    # for i in cnt:
    #     freq[i-1] = cnt[i]
    
    # # freq /= freq.max()

    # sns.set(style='darkgrid')
    # sns.set_context("notebook", font_scale=1.8, rc={"lines.linewidth": 3, 'lines.markersize': 20})
    # plt.figure(figsize=(6, 4.5))
    # plt.scatter(proj[:, 0], proj[:, 1], s=1, c=freq, cmap='viridis_r')
    # plt.colorbar()
    # plt.xlim(-2, 2)
    # plt.ylim(-2, 2)
    # # plt.axis('square')
    # # plt.show()
    # plt.savefig(log_dir + '/' + config['model'] + '-' + config['dataset'] + '.pdf', format='pdf', transparent=False, bbox_inches='tight')
    
    # from scipy.linalg import svdvals
    # svs = svdvals(embedding_matrix)
    # svs /= svs.max()
    # np.save(log_dir + '/sv.npy', svs)

    # sns.set(style='darkgrid')
    # sns.set_context("notebook", font_scale=1.8, rc={"lines.linewidth": 3, 'lines.markersize': 20})
    # plt.figure(figsize=(6, 4.5))
    # plt.plot(svs)
    # # plt.show()
    # plt.savefig(log_dir + '/svs.pdf', format='pdf', transparent=False, bbox_inches='tight')

    # model evaluation
    # test_result = trainer.evaluate(test_data, load_best_model=saved, show_progress=config['show_progress'])

    # logger.info(set_color('best valid ', 'yellow') + f': {best_valid_result}')
    # logger.info(set_color('test result', 'yellow') + f': {test_result}')

    # return {
    #     'best_valid_score': best_valid_score,
    #     'valid_score_bigger': config['valid_metric_bigger'],
    #     'best_valid_result': best_valid_result,
    #     'test_result': test_result
    # }


def objective_function(config_dict=None, config_file_list=None, saved=True):
    r""" The default objective_function used in HyperTuning

    Args:
        config_dict (dict): parameters dictionary used to modify experiment parameters
        config_file_list (list): config files used to modify experiment parameters
        saved (bool): whether to save the model
    """

    config = Config(config_dict=config_dict, config_file_list=config_file_list)
    init_seed(config['seed'], config['reproducibility'])
    logging.basicConfig(level=logging.ERROR)
    dataset = create_dataset(config)
    train_data, valid_data, test_data = data_preparation(config, dataset)
    model = get_model(config['model'])(config, train_data).to(config['device'])
    trainer = get_trainer(config['MODEL_TYPE'], config['model'])(config, model)
    best_valid_score, best_valid_result = trainer.fit(train_data, valid_data, test_data, verbose=False, saved=saved)
    test_result = trainer.evaluate(test_data, load_best_model=saved)

    return {
        'best_valid_score': best_valid_score,
        'valid_score_bigger': config['valid_metric_bigger'],
        'best_valid_result': best_valid_result,
        'test_result': test_result
    }
