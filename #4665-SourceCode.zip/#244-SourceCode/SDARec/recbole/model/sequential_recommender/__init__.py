from recbole.model.sequential_recommender.cl4srec import CL4SRec
from recbole.model.sequential_recommender.duorec import DuoRec