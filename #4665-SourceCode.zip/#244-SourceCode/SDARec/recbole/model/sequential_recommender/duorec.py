import torch
from torch import nn
import torch.nn.functional as F
from recbole.model.layers import TransformerEncoder
from recbole.model.abstract_recommender import SequentialRecommender
import torch
import enum
import math
import numpy as np
import torch as th
import torch.nn.functional as F
import torch.nn as nn
import os
import copy
import random
class DuoRec(SequentialRecommender):
    def __init__(self,config, dataset):
        super().__init__(config, dataset)
        self.config = config
        self.temperature = config['temperature']
        self.embedding_size = config['hidden_size']
        self.item_embedding = nn.Embedding(self.n_items,self.embedding_size,padding_idx=0)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=0,reduction="none")
        # self.loss_func = nn.CrossEntropyLoss()
        self.sampling_steps = config['steps']
        self.initializer_range = config["initializer_range"]
        self.sampling_noise = config['sampling_noise']
        self.tau = config['tau']
        self.sim = config['sim']
        self.lmd_sem = config['lmd_sem']
        self.aug_rec_loss_weight = config['aug_rec_loss_weight']
        self.seq2seq_loss_weight = config['seq2seq_loss_weight']
        self.gen_sem_rec_loss_weight = config['gen_sem_rec_loss_weight']
        self.contrast_loss_fct = nn.CrossEntropyLoss()

        # 模型
        self.trmencoder = TrmEncoder(config, dataset)
        self.seq2seqmodel = TrmEncoder(config, dataset)

        self.diffusion = self.getGaussDiffusion()
        self.fn = nn.Linear(config['hidden_size'], self.n_items)
        with torch.no_grad():
            self.fn.weight = self.item_embedding.weight
        self.attention = nn.Sequential(
            nn.Linear(2 * self.embedding_size, 1),
            nn.Sigmoid()
        )
        self.negative_mask = None
        

        self.apply(self._init_weights)

        # 重新处理item_embedding的pad,因为上述条件将pad的embedding设置成了非0
        # self.item_embedding.weight.data[0] = 0

    def _init_weights(self, module):
        """ Initialize the weights """
        if isinstance(module, (nn.Linear, nn.Embedding)):
            # Slightly different from the TF version which uses truncated_normal for initialization
            # cf https://github.com/pytorch/pytorch/pull/5617
            module.weight.data.normal_(mean=0.0, std=self.initializer_range)
        elif isinstance(module, nn.LayerNorm):
            module.bias.data.zero_()
            module.weight.data.fill_(1.0)
        if isinstance(module, nn.Linear) and module.bias is not None:
            module.bias.data.zero_()

    def calculate_loss(self,interaction,epoch_index): # todo 修改diffusion加入后的训练pipeline
        # with torch.autograd.profiler.profile(enabled=True) as prof:
        aug_item_seq = interaction['aug_item_id_list'] # 增强样本换成了语义增强的样本
        ori_item_seq = interaction["item_id_list"]
        ori_item_seq_len = interaction[self.ITEM_SEQ_LEN]
        sem_aug_item_seq = interaction["sem_aug"]
        target_item = interaction['item_id']
        # 插补mask,使用scatter机制，数据集已经插补了mask

        # 提前扩充到100维度，使得能够进行加速
        pad_zeros = torch.zeros_like(ori_item_seq,device=ori_item_seq.device,dtype=torch.int64)
        ori_item_seq = torch.cat([ori_item_seq,pad_zeros],dim=-1)
        sem_aug_item_seq = torch.cat([sem_aug_item_seq,pad_zeros],dim=-1)

        # item_emb
        aug_item_seq_emb = self.item_embedding(aug_item_seq)
        target_emb = self.item_embedding(target_item)
        sem_aug_item_seq_emb = self.item_embedding(sem_aug_item_seq)

        # 生成语义增强序列
        gen_sem_aug = self.seq2seq_gen(ori_item_seq)
        gen_sem_aug_emb = self.item_embedding(gen_sem_aug)


        item_seq_aug, total_loss = self.get_new_seq(aug_item_seq, aug_item_seq_emb, target_emb)
        # item_seq_aug = self.get_new_seq(aug_item_seq, aug_item_seq_emb)
        # item_seq_aug, item_seq_aug_emb, total_loss = self.get_new_seq(aug_item_seq, aug_item_seq_emb)
        # new_item_seq = self.get_new_seq(item_seq, item_seq_emb)

        # 进行插补mask
        # 不进行插补mask，进行crop操作
        # crop_seq, crop_seq_len, mask_seq, mask_seq_len, reorder_seq, reorder_seq_len, noise_seq_emb = self.cl4rec_aug(ori_item_seq, ori_item_seq_len)
        # noise_seq_emb = self.cl4rec_aug(item_seq_aug, ori_item_seq_len)

        # noise_seq = item_seq_aug
        ori_item_seq_emb = self.item_embedding(ori_item_seq)
        # crop_seq_emb = self.item_embedding(crop_seq)
        # reorder_seq_emb = self.item_embedding(reorder_seq)
        item_seq_aug_emb = self.item_embedding(item_seq_aug)

        all_item_seq = torch.cat([ori_item_seq, ori_item_seq, item_seq_aug, item_seq_aug, sem_aug_item_seq, gen_sem_aug],dim=0)
        all_item_seq_emb = torch.cat([ori_item_seq_emb, ori_item_seq_emb, item_seq_aug_emb, item_seq_aug_emb, sem_aug_item_seq_emb, gen_sem_aug_emb],dim=0)
        all_target_emb = torch.cat([target_emb, target_emb, target_emb, target_emb, target_emb, target_emb],dim=0)

        # all_item_seq = torch.cat([ori_item_seq, ori_item_seq, sem_aug_item_seq, gen_sem_aug],dim=0)
        # all_item_seq_emb = torch.cat([ori_item_seq_emb, ori_item_seq_emb, sem_aug_item_seq_emb, gen_sem_aug_emb],dim=0)
        # all_target_emb = torch.cat([target_emb, target_emb, target_emb, target_emb],dim=0)
        

        # all_item_seq = torch.cat([ori_item_seq, ori_item_seq, item_seq_aug, item_seq_aug, sem_aug_item_seq],dim=0)
        # all_item_seq_emb = torch.cat([ori_item_seq_emb, item_seq_aug_emb, ori_item_seq_emb, item_seq_aug_emb, sem_aug_item_seq_emb],dim=0)
        # all_target_emb = torch.cat([target_emb, target_emb, target_emb, target_emb, target_emb],dim=0)


        # 送入trm模型
        # alpha_ori, model_output_ori = self.trmencoder(ori_item_seq, ori_item_seq_emb)
        # _ , model_all_output = self.trmencoder(all_item_seq, all_item_seq_emb)

        # 送入Diffusion模型,item_seq, item_emb, model, x_start, reweight=True
        model_all_output = self.diffusion.training_losses(all_item_seq, all_item_seq_emb,model=self.trmencoder,x_start=all_target_emb,reweight=self.config['reweight'])
        # seq_output_ori = self.diffusion.training_losses(ori_item_seq, ori_item_seq_emb,model=self.trmencoder,x_start=target_emb,reweight=self.config['reweight'])
        # seq_output_aug = self.diffusion.training_losses(item_seq_aug, item_seq_aug_emb,model=self.trmencoder,x_start=target_emb,reweight=self.config['reweight'])
        # seq_output_sem_aug = self.diffusion.training_losses(sem_aug_item_seq, sem_aug_item_seq_emb,model=self.trmencoder,x_start=target_emb,reweight=self.config['reweight'])

        temp = all_item_seq
        last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,model_all_output.shape[-1])
        seq_output_all = torch.gather(model_all_output, dim=1, index=last_token_index).squeeze(1)

        batch_size = ori_item_seq.shape[0]
        seq_output_ori = seq_output_all[:batch_size, :]
        seq_output_anchor =seq_output_all[batch_size : 2 * batch_size, : ]
        seq_output_aug = seq_output_all[2 * batch_size : 3 * batch_size, : ]
        seq_output_aug_anchor = seq_output_all[3 * batch_size : 4 * batch_size, : ]
        seq_output_sem_aug = seq_output_all[4 * batch_size : 5 * batch_size, : ]
        seq_output_gen_sem_aug = seq_output_all[5 * batch_size : , : ]

        # batch_size = ori_item_seq.shape[0]
        # seq_output_ori = seq_output_all[:batch_size, :]
        # seq_output_anchor =seq_output_all[batch_size : 2 * batch_size, : ]
        # seq_output_sem_aug = seq_output_all[2 * batch_size : 3 * batch_size, : ]
        # seq_output_gen_sem_aug = seq_output_all[3 * batch_size : , : ]

        # batch_size = ori_item_seq.shape[0]
        # seq_output_ori = seq_output_all[:batch_size, :]
        # seq_output_aug = seq_output_all[batch_size : 2 * batch_size, : ]
        # seq_output_sem_aug = seq_output_all[2 * batch_size : , : ]


        # 新增观测当前每个epoch下，增强序列和原始序列建模信息的相似度
        # ori_path = os.path.join(self.config['base_path'],f"temp_data/seq_output/ori/seq_output_ori_epoch{epoch_index}.pt")
        # aug_path = os.path.join(self.config['base_path'],f"temp_data/seq_output/aug/seq_output_aug_epoch{epoch_index}.pt")
        # sem_path = os.path.join(self.config['base_path'],f"temp_data/seq_output/sem/seq_output_sem_epoch{epoch_index}.pt")
        # gen_sem_path = os.path.join(self.config['base_path'],f"temp_data/seq_output/gen_sem/seq_output_gen_sem_epoch{epoch_index}.pt")
        # target_item_path = os.path.join(self.config['base_path'],f"temp_data/seq_output/target_item_emb/target_item_emb_epoch{epoch_index}.pt")
        # all_item_emb_path = os.path.join(self.config['base_path'],f"temp_data/seq_output/all_item_emb/all_item_emb_epoch{epoch_index}.pt")

        # torch.save(seq_output_ori,ori_path)
        # torch.save(seq_output_aug,aug_path)
        # torch.save(seq_output_sem_aug,sem_path)
        # torch.save(seq_output_gen_sem_aug,gen_sem_path)
        # torch.save(target_emb,target_item_path)
        # torch.save(self.item_embedding.weight.data,all_item_emb_path)

        # model_output_ori = self.diffusion.training_losses(ori_item_seq, ori_item_seq_emb,model=self.trmencoder,x_start=target_emb,reweight=self.config['reweight'])
        # model_output_aug = self.diffusion.training_losses(item_seq_aug, item_seq_aug_emb,model=self.trmencoder,x_start=target_emb,reweight=self.config['reweight'])
        # model_output_sem_aug = self.diffusion.training_losses(sem_aug_item_seq, sem_aug_item_seq_emb,model=self.trmencoder,x_start=target_emb,reweight=self.config['reweight'])

        # 获取原始序列通道的输出
        # temp = ori_item_seq
        # last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,seq_output_ori.shape[-1])
        # seq_output_ori = torch.gather(seq_output_ori, dim=1, index=last_token_index).squeeze(1)
        # seq_output_ori = F.normalize(seq_output_ori, dim=-1)

        # 获取语义增强序列通道的输出
        # temp = item_seq_aug
        # last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,seq_output_aug.shape[-1])
        # seq_output_aug = torch.gather(seq_output_aug, dim=1, index=last_token_index).squeeze(1)
        # seq_output_sem_aug = F.normalize(seq_output_sem_aug, dim=-1)

        # temp = sem_aug_item_seq
        # last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,seq_output_sem_aug.shape[-1])
        # seq_output_sem_aug = torch.gather(seq_output_sem_aug, dim=1, index=last_token_index).squeeze(1)
        # seq_output_sem_aug = F.normalize(seq_output_sem_aug, dim=-1)

        # # 获取增强序列通道的输出，因为增强序列中也含有未插补序列，因此需要分开抽取
        # temp = aug_item_seq
        # last_token_index = torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1
        # insert_extra_index = torch.where((torch.sum(torch.where(temp == 1, 1, 0), dim=-1) - 1) > 0, 0, 0)
        # last_token_index = last_token_index - insert_extra_index
        # last_token_index = last_token_index.unsqueeze(-1).unsqueeze(-1).expand(-1,1,model_output_ori.shape[-1])
        # seq_output_aug = torch.gather(model_output_aug, dim=1, index=last_token_index).squeeze(1)
        # # seq_output_aug = F.normalize(seq_output_aug, dim=-1)

        # 计算最终的attention值
        # lam = self.attention(torch.cat([seq_output_ori,seq_output_aug],dim=-1))
        # # # lam = 0.9
        # seq_output = seq_output_aug * (1 - lam) + seq_output_ori * lam
        # seq_output = seq_output_ori

        # 计算logits loss
        all_item_emb = self.item_embedding.weight
        # all_item_emb = F.normalize(all_item_emb, dim=-1)
        # logits = torch.matmul(seq_output, all_item_emb.transpose(0, 1)) / self.temperature
        ori_logits = torch.matmul(seq_output_ori, all_item_emb.transpose(0, 1))
        aug_logits = torch.matmul(seq_output_aug, all_item_emb.transpose(0, 1))
        ori_loss = self.loss_func(ori_logits, target_item).mean()
        aug_loss = self.loss_func(aug_logits, target_item).mean()
        gen_sem_logits = torch.matmul(seq_output_gen_sem_aug, all_item_emb.transpose(0, 1))
        gen_sem_loss = self.loss_func(gen_sem_logits, target_item).mean()



        # 锚
        # model_output_anchor = self.diffusion.training_losses(ori_item_seq, ori_item_seq_emb,model=self.trmencoder,x_start=target_emb,reweight=self.config['reweight'])
        # model_output_aug_anchor = self.diffusion.training_losses(item_seq_aug, item_seq_aug_emb,model=self.trmencoder,x_start=target_emb,reweight=self.config['reweight'])

        # 获取原始序列通道的输出
        # temp = ori_item_seq
        # last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,model_output_anchor.shape[-1])
        # seq_output_anchor = torch.gather(model_output_anchor, dim=1, index=last_token_index).squeeze(1)
        # # seq_output_anchor = F.normalize(seq_output_anchor, dim=-1)

        # temp = item_seq_aug
        # last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,model_output_aug_anchor.shape[-1])
        # seq_output_aug_anchor = torch.gather(model_output_aug_anchor, dim=1, index=last_token_index).squeeze(1)

        # 计算插补样本的info NCE loss
        # seq_output_aug = 0.5 * seq_output_aug  + 0.5 * seq_output_ori
        # sem_nce_logits, sem_nce_labels = self.info_nce(seq_output_ori, seq_output_aug, temp=self.tau, batch_size=ori_item_seq.shape[0], sim=self.sim)
        # insert_mask_contrasct_loss = self.contrast_loss_fct(sem_nce_logits,sem_nce_labels)
        seq_output_aug_anchor = seq_output_aug_anchor * 0.5 + seq_output_anchor * 0.5
        sem_nce_logits, sem_nce_labels = self.info_nce(seq_output_aug_anchor, seq_output_sem_aug, temp=self.tau, batch_size=ori_item_seq.shape[0], sim=self.sim)
        insert_mask_contrasct_loss = self.contrast_loss_fct(sem_nce_logits,sem_nce_labels)

        # 计算语义增强样本的info NCE loss
        # seq_output_aug = 0.5 * seq_output_aug  + 0.5 * seq_output_ori
        sem_aug_nce_logits, sem_aug_nce_labels = self.info_nce(seq_output_anchor, seq_output_sem_aug, temp=self.tau, batch_size=ori_item_seq.shape[0], sim=self.sim)
        # sem_nce_logits, sem_nce_labels = self.info_nce(seq_output_ori, seq_output_aug, temp=self.tau, batch_size=ori_item_seq.shape[0], sim=self.sim)
        sem_aug_contrasct_loss = self.contrast_loss_fct(sem_aug_nce_logits,sem_aug_nce_labels)

        # ori与增强序列进行增强
        gen_sem_aug_nce_logits, gen_sem_aug_nce_labels = self.info_nce(seq_output_anchor, seq_output_gen_sem_aug, temp=self.tau, batch_size=ori_item_seq.shape[0], sim=self.sim)
        gen_sem_aug_contrasct_loss = self.contrast_loss_fct(gen_sem_aug_nce_logits,gen_sem_aug_nce_labels)

        # 前期可能以生成为主，待生成质量提升后，进行对比学习
        # probability = 1 - (epoch_idx / 70)
        # if (random.random() > probability) and epoch_idx > 25  :
        #     return loss + self.lmd_sem * sem_aug_contrasct_loss + self.lmd_sem * insert_mask_contrasct_loss + self.lmd_sem * total_loss # 后期促进生成，此处插补的infoloss感觉不需要
        # else:
        #     return loss + self.lmd_sem * sem_aug_contrasct_loss # 前期依靠高质量样本来促进模型学习
        
        # print(prof.key_averages().table(sort_by="self_cpu_time_total"))



        # 进行seq2seq任务
        # seq2seq_input = torch.cat([ori_item_seq,torch.ones_like(ori_item_seq,dtype=torch.int64,device=ori_item_seq.device)],dim=-1) # 拼接相同长度的mask作为预测mask
        # seq2seq_input_emb = self.item_embedding(seq2seq_input) # [256,100,64]

        # seq2seq_target_seq = sem_aug_item_seq.view(-1)

        # all_output = self.seq2seqmodel.seq2seq_forward(seq2seq_input,seq2seq_input_emb) # [256,100,64]

        # target_output = all_output[:,int(all_output.shape[1] / 2):,:]

        # all_item_embedding = self.item_embedding.weight
        # scores = torch.matmul(target_output,all_item_embedding.transpose(0,1)) # [256,100,item_num]
        # # scores = self.fn(output)
        # scores[:, :, 1] = -torch.inf  # 屏蔽掉mask
        # scores[:, :, 0] = -torch.inf

        # scores = scores.view(-1,scores.shape[-1])
        # seq2seq_loss = self.loss_func(scores,seq2seq_target_seq)
        # seq2seq_loss = torch.where(seq2seq_target_seq != 0,seq2seq_loss,0).mean()
        

        return ori_loss + self.gen_sem_rec_loss_weight * gen_sem_loss + self.aug_rec_loss_weight * aug_loss + self.lmd_sem * (sem_aug_contrasct_loss + insert_mask_contrasct_loss + gen_sem_aug_contrasct_loss)# 后期促进生成，此处插补的infoloss感觉不需要
        # return ori_loss + self.gen_sem_rec_loss_weight * gen_sem_loss + (self.lmd_sem / 2 ) * sem_aug_contrasct_loss + (self.lmd_sem / 2 ) * gen_sem_aug_contrasct_loss# 后期促进生成，此处插补的infoloss感觉不需要
        # return ori_loss + self.gen_sem_rec_loss_weight * gen_sem_loss + (self.lmd_sem / 2 ) * sem_aug_contrasct_loss + (self.lmd_sem / 2 ) * gen_sem_aug_contrasct_loss# 后期促进生成，此处插补的infoloss感觉不需要
        # return ori_loss + self.lmd_sem * sem_aug_contrasct_loss

    def full_sort_predict(self, interaction):
        item_seq = interaction['item_id_list']
        # aug_item_seq = interaction['aug_item_id_list']

        # item_emb
        item_seq_emb = self.item_embedding(item_seq)
        # aug_item_seq_emb = self.item_embedding(aug_item_seq)

        # 送入transformer模型
        # _ , model_output = self.trmencoder(item_seq, item_seq_emb)

        # 使用aug数据进行推理
        # item_seq_aug, total_loss = self.get_new_seq(aug_item_seq, aug_item_seq_emb)
        # item_seq_aug_emb = self.item_embedding(item_seq_aug)

        # 送入Diffusion模型
        target_emb = torch.randn_like(item_seq_emb[:,0,:],device=item_seq.device)
        x_0_hat, alpha = self.diffusion.p_sample(item_seq=item_seq, item_emb=item_seq_emb, model=self.trmencoder, x_start=target_emb, steps=self.sampling_steps, sampling_noise=self.sampling_noise)
        # x_0_hat, alpha = self.diffusion.p_sample(item_seq=item_seq_aug, item_emb=item_seq_aug_emb, model=self.trmencoder, x_start=target_emb, steps=self.sampling_steps, sampling_noise=self.sampling_noise)

        # 抽取序列末尾token
        # temp = item_seq
        # last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,model_output.shape[-1])
        # seq_output = torch.gather(model_output, dim=1, index=last_token_index).squeeze(1)
        # seq_output = F.normalize(seq_output, dim=-1)
        seq_output = x_0_hat

        # 计算logits
        all_item_emb = self.item_embedding.weight
        # all_item_emb = F.normalize(all_item_emb, dim=-1)
        # scores = torch.matmul(seq_output, all_item_emb.transpose(0, 1)) / self.temperature
        scores = torch.matmul(seq_output, all_item_emb.transpose(0, 1))

        return scores
    
    def cl4rec_aug(self, item_seq, item_seq_len):
        aug_seq_crop_list = []
        aug_len_crop_list = []
        aug_seq_mask_list = []
        aug_len_mask_list = []
        aug_seq_reorder_list = []
        aug_len_reorder_list = []

        aug_seq_noise_emb_list = []

        for seq, length in zip(item_seq, item_seq_len):
            # 如果是长度超过1，则针对每个序列都进行如下增强操作,否则保持自身
            seq_emb = self.item_embedding(seq)
            if length > 1:
                aug_seq_crop, aug_len_crop = self.item_crop(seq, length)
                aug_seq_mask, aug_len_mask = self.item_mask(seq, length)
                aug_seq_reorder, aug_len_reorder = self.item_reorder(seq, length)
                
                aug_seq_noise_emb = self.item_noise(seq,seq_emb,length)
            else:
                aug_seq_crop, aug_len_crop = seq, length
                aug_seq_mask, aug_len_mask = seq, length
                aug_seq_reorder, aug_len_reorder = seq, length
                aug_seq_noise_emb = seq_emb
            
            aug_seq_crop_list.append(aug_seq_crop)
            aug_len_crop_list.append(aug_len_crop)

            aug_seq_mask_list.append(aug_seq_mask)
            aug_len_mask_list.append(aug_len_mask)

            aug_seq_reorder_list.append(aug_seq_reorder)
            aug_len_reorder_list.append(aug_len_reorder)

            aug_seq_noise_emb_list.append(aug_seq_noise_emb)
        
        return torch.stack(aug_seq_crop_list), torch.stack(aug_len_crop_list), torch.stack(aug_seq_mask_list), torch.stack(aug_len_mask_list), torch.stack(aug_seq_reorder_list), torch.stack(aug_len_reorder_list), torch.stack(aug_seq_noise_emb_list)
        # return torch.stack(aug_seq_noise_emb_list)

    def item_crop(self, item_seq, item_seq_len, eta=0.6):
        num_left = math.floor(item_seq_len * eta)
        crop_begin = random.randint(0, item_seq_len - num_left)
        croped_item_seq = np.zeros(item_seq.shape[0])
        if crop_begin + num_left < item_seq.shape[0]:
            croped_item_seq[:num_left] = item_seq.cpu().detach().numpy()[crop_begin:crop_begin + num_left]
        else:
            croped_item_seq[:num_left] = item_seq.cpu().detach().numpy()[crop_begin:]
        return torch.tensor(croped_item_seq, dtype=torch.long, device=item_seq.device),\
               torch.tensor(num_left, dtype=torch.long, device=item_seq.device)
    
    def item_mask(self, item_seq, item_seq_len, gamma=0.3):
        num_mask = math.floor(item_seq_len * gamma)
        mask_index = random.sample(range(item_seq_len), k=num_mask)
        masked_item_seq = item_seq.cpu().detach().numpy().copy()
        masked_item_seq[mask_index] = self.n_items  # token 0 has been used for semantic masking
        return torch.tensor(masked_item_seq, dtype=torch.long, device=item_seq.device), item_seq_len

    def item_reorder(self, item_seq, item_seq_len, beta=0.6):
        num_reorder = math.floor(item_seq_len * beta)
        reorder_begin = random.randint(0, item_seq_len - num_reorder)
        reordered_item_seq = item_seq.cpu().detach().numpy().copy()
        shuffle_index = list(range(reorder_begin, reorder_begin + num_reorder))
        random.shuffle(shuffle_index)
        reordered_item_seq[reorder_begin:reorder_begin + num_reorder] = reordered_item_seq[shuffle_index]
        return torch.tensor(reordered_item_seq, dtype=torch.long, device=item_seq.device), item_seq_len
    
    def item_noise(self,item_seq, item_seq_emb, item_seq_len, beta=0.3):
        num_mask = math.floor(item_seq_len * beta)
        noise_index = random.sample(range(item_seq_len), k=num_mask)
        masked_item_seq = item_seq.cpu().detach().numpy().copy()
        item_seq_emb[noise_index] = torch.randn_like(item_seq_emb[0])  # token 0 has been used for semantic masking
        
        return item_seq_emb

    # 此处一定不要记录梯度信息，没有loss输出则不用梯度信息，可以加快训练速度
    @torch.no_grad()
    def get_new_seq(self,item_seq, item_emb, target_emb=None):
        '''
        输入插补mask，对mask进行预测
        :param item_seq:
        :return:
        '''
        # 需要伪造一个x_t和ts，以便推理时只使用transformer组件
        x_t = torch.zeros_like(item_emb[:,0,:],device=item_emb.device)
        ts = torch.zeros((item_seq.shape[0],),device=item_seq.device)

        # 送入transformer
        # alpha, output = self.trmencoder(item_seq, item_emb)
        #送入Diffusion中的transformer
        alpha, output = self.trmencoder(item_seq, item_emb, x_t, ts)

        # 计算整个序列的top1 token
        # output = F.normalize(output,dim=-1)
        all_item_embedding = self.item_embedding.weight
        # all_item_embedding = F.normalize(all_item_embedding,dim=-1)
        # scores = torch.matmul(output,all_item_embedding.transpose(0,1)) / self.temperature
        scores = torch.matmul(output,all_item_embedding.transpose(0,1))
        # scores = self.fn(output)
        scores[:, :, 1] = -torch.inf  # 屏蔽掉mask
        scores[:, :, 0] = -torch.inf
        value, index = torch.topk(scores, k=1, dim=-1)
        index = index.squeeze(-1)
        new_item_seq = torch.where(item_seq == 1, index, item_seq)

        # 计算插补loss
        # scores = scores.view(-1,scores.shape[-1])
        # item_seq_expand = copy.deepcopy(item_seq).view(-1)
        # # # reconstruct_loss = self.loss_func(scores.transpose(1,2),item_seq) # [2048,50] # 注意cross entropy三维情况
        # # # reconstruct_loss = torch.where((item_seq != 1) & (item_seq != 0),reconstruct_loss,0)
        # reconstruct_loss = self.loss_func(scores,item_seq_expand)
        # reconstruct_loss = reconstruct_loss.view(item_seq.shape[0],-1)
        # reconstruct_loss = torch.where((item_seq != 1) & (item_seq != 0),reconstruct_loss,0)

        # 计算对比loss，让插补的token embedding和原始token embedding相似，协同过滤信息趋于一致
        # mask_flag = torch.where(item_seq == 1, 1, 0)
        # ori_flag = torch.where((item_seq != 1) & (item_seq != 0), 1, 0)

        # new_mask_seq = torch.mul(new_item_seq,mask_flag)
        # new_mask_seq_emb = self.item_embedding(new_mask_seq)
        # new_ori_seq = torch.mul(new_item_seq,ori_flag)
        # new_ori_seq_emb = self.item_embedding(new_ori_seq)
        
        # # # 忽略pad位置
        # mask_mean_emb = torch.mean(new_mask_seq_emb,dim=1)
        # ori_mean_emb = torch.mean(new_ori_seq_emb,dim=1)

        # # 修正info loss使其插补的token与target_item一致
        # mask_mean_emb = mask_mean_emb.squeeze(1)
        # ori_mean_emb = target_emb

        # # 填充本身未进行插补的embedding
        # # mask_mean_emb = torch.where(mask_mean_emb == 0,ori_mean_emb,mask_mean_emb)

        # # # infoLoss
        # self.negative_mask = (~torch.eye(item_seq.shape[0] * 2, item_seq.shape[0] * 2, dtype=torch.bool,device=item_seq.device)).float()
        # all_mean_emb = torch.cat([mask_mean_emb,ori_mean_emb],dim=0)
        # sim_matrix = F.cosine_similarity(all_mean_emb.unsqueeze(1),all_mean_emb.unsqueeze(0), dim=2)

        # sim_ij = torch.diag(sim_matrix, item_seq.shape[0])
        # sim_ji = torch.diag(sim_matrix, -item_seq.shape[0])
        # positives = torch.cat([sim_ij, sim_ji], dim=0)

        # temperature = self.temperature
        # nominator = torch.exp(positives / temperature)             # 2*bs
        # denominator = self.negative_mask * torch.exp(sim_matrix / temperature)             # 2*bs, 2*bs
    
        # loss_partial = -torch.log(nominator / torch.sum(denominator, dim=1))        # 2*bs
        # info_loss = torch.sum(loss_partial) / (2 * item_seq.shape[0])
        
        #使用JS散度衡量距离
        # M = ((mask_mean_emb + ori_mean_emb) / 2) + 1e-12

        # kl_criterion = torch.nn.KLDivLoss(reduction='sum')
        # Js_loss = 0.5 * kl_criterion(torch.softmax(mask_mean_emb,dim=-1).log(),torch.softmax(M,dim=-1)) + 0.5 * kl_criterion(torch.softmax(ori_mean_emb,dim=-1).log(),torch.softmax(M,dim=-1))
        

        # total_loss = info_loss + reconstruct_loss.mean()
        # total_loss = reconstruct_loss.mean()
        total_loss = 0
        # total_loss = Js_loss

        # 不固定原始序列，固定pad
        # new_item_seq = torch.where(item_seq != 0, index, item_seq)

        # 先暂时直接使用index作为新的扩充序列，也即可能会改变原本的token序列
        return new_item_seq.squeeze(-1), total_loss
        # return new_item_seq, total_loss
        # return new_item_seq.squeeze(-1)
        # return new_item_seq.squeeze(-1), output , total_loss

    # 需要梯度然后更新模型参数
    def seq2seq_gen(self,ori_item_seq):
        # 生成长度为10的序列
        target_mask = torch.ones((ori_item_seq.shape[0],self.config['gen_sem_length']),dtype=torch.int64,device=ori_item_seq.device) # [256,10]
        seq2seq_predict_input = torch.cat([ori_item_seq,target_mask],dim=-1)
        seq2seq_predict_input_emb = self.item_embedding(seq2seq_predict_input)
        output = self.seq2seqmodel.seq2seq_forward(seq2seq_predict_input,seq2seq_predict_input_emb)
        target_predict_output = output[:,target_mask.shape[-1] : , : ]

        all_item_embedding = self.item_embedding.weight
        scores = torch.matmul(target_predict_output,all_item_embedding.transpose(0,1)) # [256,10,item_num]
        scores[:, :, 1] = -torch.inf  # 屏蔽掉mask
        scores[:, :, 0] = -torch.inf
        value, index = torch.topk(scores, k=1, dim=-1)
        index = index.squeeze(-1) # [256,10]
        gen_sem_aug = index
        return gen_sem_aug

    def info_nce(self, z_i, z_j, temp, batch_size, sim='dot'):
        """
        We do not sample negative examples explicitly.
        Instead, given a positive pair, similar to (Chen et al., 2017), we treat the other 2(N − 1) augmented examples within a minibatch as negative examples.
        """
        N = 2 * batch_size
    
        z = torch.cat((z_i, z_j), dim=0)
    
        if sim == 'cos':
            sim = nn.functional.cosine_similarity(z.unsqueeze(1), z.unsqueeze(0), dim=2) / temp
        elif sim == 'dot':
            sim = torch.mm(z, z.T) / temp
    
        sim_i_j = torch.diag(sim, batch_size)
        sim_j_i = torch.diag(sim, -batch_size)
    
        positive_samples = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)
        mask = self.mask_correlated_samples(batch_size)
        negative_samples = sim[mask].reshape(N, -1)
    
        labels = torch.zeros(N).to(positive_samples.device).long()
        logits = torch.cat((positive_samples, negative_samples), dim=1)
        return logits, labels

    def mask_correlated_samples(self, batch_size):
        '''
        将两个对角线和主对角线元素进行mask
        '''
        N = 2 * batch_size
        mask = torch.ones((N, N), dtype=bool)
        mask = mask.fill_diagonal_(0)
        for i in range(batch_size):
            mask[i, batch_size + i] = 0
            mask[batch_size + i, i] = 0
        return mask

    def getGaussDiffusion(self):
        if self.config['mean_type'] == 'x0':
            mean_type = ModelMeanType.START_X
        elif self.config['mean_type'] == 'eps':
            mean_type = ModelMeanType.EPSILON
        else:
            raise ValueError("Unimplemented mean type %s" % self.config['mean_type'])

        diffusion = GaussianDiffusion(mean_type, self.config['noise_schedule'], self.config['noise_scale'],
                                      self.config['noise_min'], self.config['noise_max'], self.config['steps'],
                                      self.config['device']).to(self.config['device'])
        return diffusion

class ModelMeanType(enum.Enum):
    START_X = enum.auto()  # the model predicts x_0
    EPSILON = enum.auto()  # the model predicts epsilon
class GaussianDiffusion(nn.Module):
    def __init__(self, mean_type, noise_schedule, noise_scale, noise_min, noise_max, \
                 steps, device, history_num_per_term=10, beta_fixed=True):

        self.mean_type = mean_type
        self.noise_schedule = noise_schedule
        self.noise_scale = noise_scale
        self.noise_min = noise_min
        self.noise_max = noise_max
        self.steps = steps
        self.device = device

        self.history_num_per_term = history_num_per_term
        self.Lt_history = th.zeros(steps, history_num_per_term, dtype=th.float64).to(device)
        self.Lt_count = th.zeros(steps, dtype=int).to(device)

        if noise_scale != 0.:
            self.betas = th.tensor(self.get_betas(), dtype=th.float64).to(self.device)
            if beta_fixed:
                self.betas[0] = 0.00001  # Deep Unsupervised Learning using Noneequilibrium Thermodynamics 2.4.1
                # The variance \beta_1 of the first step is fixed to a small constant to prevent overfitting.
            assert len(self.betas.shape) == 1, "betas must be 1-D"
            assert len(self.betas) == self.steps, "num of betas must equal to diffusion steps"
            assert (self.betas > 0).all() and (self.betas <= 1).all(), "betas out of range"

            self.calculate_for_diffusion()

        super(GaussianDiffusion, self).__init__()

    def get_betas(self):
        """
        Given the schedule name, create the betas for the diffusion process.
        """
        if self.noise_schedule == "linear" or self.noise_schedule == "linear-var":
            # start = self.noise_scale * self.noise_min
            # end = self.noise_scale * self.noise_max
            scale = 1000 / self.steps
            start = scale * 0.0001
            end = scale * 0.02
            if self.noise_schedule == "linear":
                return np.linspace(start, end, self.steps, dtype=np.float64)
            else:
                return betas_from_linear_variance(self.steps, np.linspace(start, end, self.steps, dtype=np.float64))
        elif self.noise_schedule == "cosine":
            return betas_for_alpha_bar(
                self.steps,
                lambda t: math.cos((t + 0.008) / 1.008 * math.pi / 2) ** 2
            )
        elif self.noise_schedule == "trunc_cos":
            return betas_for_alpha_bar2(
                self.steps,
                lambda t: np.cos((t + 0.1) / 1.1 * np.pi / 2) ** 2,
            )

        elif self.noise_schedule == "binomial":  # Deep Unsupervised Learning using Noneequilibrium Thermodynamics 2.4.1
            ts = np.arange(self.steps)
            betas = [1 / (self.steps - t + 1) for t in ts]
            return betas
        elif self.noise_schedule == 'sqrt':
            return betas_for_alpha_bar(
                self.steps,
                lambda t: 1 - np.sqrt(t + 0.0001),
            )
        elif self.noise_schedule == 'trunc_lin':
            scale = 1000 / self.steps
            beta_start = scale * 0.0001 + 0.01
            beta_end = scale * 0.02 + 0.01
            if beta_end > 1:
                beta_end = scale * 0.001 + 0.01
            return np.linspace(
                beta_start, beta_end, self.steps, dtype=np.float64
            )
        elif self.noise_schedule == 'pw_lin':
            scale = 1000 / self.steps
            beta_start = scale * 0.0001 + 0.01
            beta_mid = scale * 0.0001  #scale * 0.02
            beta_end = scale * 0.02
            first_part = np.linspace(
                beta_start, beta_mid, 10, dtype=np.float64
            )
            second_part = np.linspace(
                beta_mid, beta_end, self.steps - 10 , dtype=np.float64
            )
            return np.concatenate(
                [first_part, second_part]
            )
    


        else:
            raise NotImplementedError(f"unknown beta schedule: {self.noise_schedule}!")

    def calculate_for_diffusion(self):
        alphas = 1.0 - self.betas
        self.alphas_cumprod = th.cumprod(alphas, axis=0).to(self.device)
        self.alphas_cumprod_prev = th.cat([th.tensor([1.0]).to(self.device), self.alphas_cumprod[:-1]]).to(
            self.device)  # alpha_{t-1}
        self.alphas_cumprod_next = th.cat([self.alphas_cumprod[1:], th.tensor([0.0]).to(self.device)]).to(
            self.device)  # alpha_{t+1}
        assert self.alphas_cumprod_prev.shape == (self.steps,)

        self.sqrt_alphas_cumprod = th.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = th.sqrt(1.0 - self.alphas_cumprod)
        self.log_one_minus_alphas_cumprod = th.log(1.0 - self.alphas_cumprod)
        self.sqrt_recip_alphas_cumprod = th.sqrt(1.0 / self.alphas_cumprod)
        self.sqrt_recipm1_alphas_cumprod = th.sqrt(1.0 / self.alphas_cumprod - 1)

        self.posterior_variance = (
                self.betas * (1.0 - self.alphas_cumprod_prev) / (1.0 - self.alphas_cumprod)
        )

        self.posterior_log_variance_clipped = th.log(
            th.cat([self.posterior_variance[1].unsqueeze(0), self.posterior_variance[1:]])
        )
        self.posterior_mean_coef1 = (
                self.betas * th.sqrt(self.alphas_cumprod_prev) / (1.0 - self.alphas_cumprod)
        )
        self.posterior_mean_coef2 = (
                (1.0 - self.alphas_cumprod_prev)
                * th.sqrt(alphas)
                / (1.0 - self.alphas_cumprod)
        )

    def p_sample(self,item_seq, item_emb, model, x_start, steps, sampling_noise=None):
        assert steps <= self.steps, "Too much steps in inference."
        # if steps == 0:
        #     x_t = x_start
        # else:
        #     t = th.tensor([steps - 1] * x_start.shape[0]).to(x_start.device)
        #     noise = th.randn_like(x_start)
        #     x_t = self.q_sample(x_start, t, noise=noise)
        x_t = x_start
        indices = list(range(self.steps))[::-1]

        if self.noise_scale == 0.:
            for i in indices:
                t = th.tensor([i] * x_t.shape[0]).to(x_start.device)
                x_t = model(x_t, t)
            return x_t

        # 记录最后一次的注意力值
        alpha = None
        for i in indices:
            t = th.tensor([i] * x_t.shape[0]).to(x_start.device)
            out = self.p_mean_variance(item_seq, item_emb, model, x_t, t)
            alpha = out["alpha"]
            if sampling_noise:
                noise = th.randn_like(x_t)
                nonzero_mask = (
                    (t != 0).float().view(-1, *([1] * (len(x_t.shape) - 1)))
                )  # no noise when t == 0
                x_t = out["mean"] + nonzero_mask * th.exp(0.5 * out["log_variance"]) * noise
            else:
                x_t = out["mean"]

        return x_t , alpha # 返回最后一次的注意力值

    def training_losses(self,item_seq, item_emb, model, x_start, reweight=False):
        '''
        diffusion start,
        :param model: 预测器,会调用其forward函数
        :param x_start: batch data，当前需要进行扩散的数据，此处为batch ，seq_len ，dim的embedding
        :param reweight: Diffunion的设置
        :return:
        '''
        batch_size, device = x_start.size(0), x_start.device
        ts, pt = self.sample_timesteps(batch_size, device, 'uniform')
        noise = th.randn_like(x_start)
        if self.noise_scale != 0.:
            x_t = self.q_sample(x_start, ts, noise)
        else:
            x_t = x_start
        terms = {}
        ################################## 模型运行输出 #################################
        alpha, model_output = model(item_seq, item_emb, x_t, ts)
        ###############################################################################
        target = {
            ModelMeanType.START_X: x_start,
            ModelMeanType.EPSILON: noise,
        }[self.mean_type]

        # assert model_output.shape == target.shape == x_start.shape

        # if reweight == True:
        #     if self.mean_type == ModelMeanType.START_X:
        #         weight = self.SNR(ts - 1) - self.SNR(ts)
        #         weight = th.where((ts == 0), 1.0, weight)
        #     elif self.mean_type == ModelMeanType.EPSILON:
        #         weight = (1 - self.alphas_cumprod[ts]) / (
        #                     (1 - self.alphas_cumprod_prev[ts]) ** 2 * (1 - self.betas[ts]))
        #         weight = th.where((ts == 0), 1.0, weight)
        #         likelihood = mean_flat((x_start - self._predict_xstart_from_eps(x_t, ts, model_output)) ** 2 / 2.0)
        #         loss = th.where((ts == 0), likelihood, mse)
        # else:
        #     weight = th.tensor([1.0] * len(target)).to(device)

        # terms["loss"] = weight * loss
        # terms["mse"] = weight * mse
        # update Lt_history & Lt_count
        # # 这和重要性采样有关
        # for t, loss in zip(ts, terms["mse"]):
        #     if self.Lt_count[t] == self.history_num_per_term:
        #         Lt_history_old = self.Lt_history.clone()
        #         self.Lt_history[t, :-1] = Lt_history_old[t, 1:]
        #         self.Lt_history[t, -1] = loss.detach()
        #     else:
        #         try:
        #             self.Lt_history[t, self.Lt_count[t]] = loss.detach()
        #             self.Lt_count[t] += 1
        #         except:
        #             print(t)
        #             print(self.Lt_count[t])
        #             print(loss)
        #             raise ValueError

        # terms["mse"] /= pt
        return model_output
    def q_mean_variance(self, x_start, t):
        """
        Get the distribution q(x_t | x_0).

        :param x_start: the [N x C x ...] tensor of noiseless inputs.
        :param t: the number of diffusion steps (minus 1). Here, 0 means one step.
        :return: A tuple (mean, variance, log_variance), all of x_start's shape.
        """
        mean = (
            self._extract_into_tensor(self.sqrt_alphas_cumprod, t, x_start.shape) * x_start
        )
        variance = self._extract_into_tensor(1.0 - self.alphas_cumprod, t, x_start.shape)
        log_variance = self._extract_into_tensor(
            self.log_one_minus_alphas_cumprod, t, x_start.shape
        )
        return mean, variance, log_variance

    def sample_timesteps(self, batch_size, device, method='uniform', uniform_prob=0.001):
        if method == 'importance':  # importance sampling
            if not (self.Lt_count == self.history_num_per_term).all():
                return self.sample_timesteps(batch_size, device, method='uniform')

            Lt_sqrt = th.sqrt(th.mean(self.Lt_history ** 2, axis=-1))
            pt_all = Lt_sqrt / th.sum(Lt_sqrt)
            pt_all *= 1 - uniform_prob
            pt_all += uniform_prob / len(pt_all)

            assert pt_all.sum(-1) - 1. < 1e-5

            t = th.multinomial(pt_all, num_samples=batch_size, replacement=True)
            pt = pt_all.gather(dim=0, index=t) * len(pt_all)

            return t, pt

        elif method == 'uniform':  # uniform sampling
            t = th.randint(0, self.steps, (batch_size,), device=device).long()
            pt = th.ones_like(t).float()

            return t, pt

        else:
            raise ValueError

    def q_sample(self, x_start, t, noise=None, mask=None):
        if noise is None:
            noise = th.randn_like(x_start)
        assert noise.shape == x_start.shape

        x_t = self._extract_into_tensor(self.sqrt_alphas_cumprod, t, x_start.shape) * x_start+ self._extract_into_tensor(self.sqrt_one_minus_alphas_cumprod, t, x_start.shape)*noise

        if mask == None:
            return x_t
        else:
            mask = th.broadcast_to(mask.unsqueeze(dim=-1), x_start.shape)
            return th.where(mask==0, x_start, x_t)

    def q_posterior_mean_variance(self, x_start, x_t, t):
        """
        Compute the mean and variance of the diffusion posterior:
            q(x_{t-1} | x_t, x_0)
        """
        assert x_start.shape == x_t.shape
        posterior_mean = (
                self._extract_into_tensor(self.posterior_mean_coef1, t, x_t.shape) * x_start
                + self._extract_into_tensor(self.posterior_mean_coef2, t, x_t.shape) * x_t
        )
        posterior_variance = self._extract_into_tensor(self.posterior_variance, t, x_t.shape)
        posterior_log_variance_clipped = self._extract_into_tensor(
            self.posterior_log_variance_clipped, t, x_t.shape
        )
        assert (
                posterior_mean.shape[0]
                == posterior_variance.shape[0]
                == posterior_log_variance_clipped.shape[0]
                == x_start.shape[0]
        )
        return posterior_mean, posterior_variance, posterior_log_variance_clipped

    def p_mean_variance(self,item_seq, item_emb, model, x, t):
        """
        Apply the model to get p(x_{t-1} | x_t), as well as a prediction of
        the initial x, x_0.
        """
        B, C = x.shape[:2]
        assert t.shape == (B,)
        alpha, output = model(item_seq, item_emb, x, t)
        temp = item_seq
        last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,output.shape[-1])
        seq_output = torch.gather(output, dim=1, index=last_token_index).squeeze(1)
	    # seq_output = output[:,-1,:]
        # seq_output = F.normalize(seq_output, dim=-1)
        model_output = seq_output # 取最后一个token作为噪声的预测恢复项

        model_variance = self.posterior_variance
        model_log_variance = self.posterior_log_variance_clipped

        model_variance = self._extract_into_tensor(model_variance, t, x.shape)
        model_log_variance = self._extract_into_tensor(model_log_variance, t, x.shape)

        if self.mean_type == ModelMeanType.START_X:
            pred_xstart = model_output
        elif self.mean_type == ModelMeanType.EPSILON:
            pred_xstart = self._predict_xstart_from_eps(x, t, eps=model_output)
        else:
            raise NotImplementedError(self.mean_type)

        model_mean, _, _ = self.q_posterior_mean_variance(x_start=pred_xstart, x_t=x, t=t)

        assert (
                model_mean.shape == model_log_variance.shape == pred_xstart.shape == x.shape
        )

        return {
            "mean": model_mean,
            "variance": model_variance,
            "log_variance": model_log_variance,
            "pred_xstart": pred_xstart,
            "alpha": alpha
        }

    def _predict_xstart_from_eps(self, x_t, t, eps):
        assert x_t.shape == eps.shape
        return (
                self._extract_into_tensor(self.sqrt_recip_alphas_cumprod, t, x_t.shape) * x_t
                - self._extract_into_tensor(self.sqrt_recipm1_alphas_cumprod, t, x_t.shape) * eps
        )

    def SNR(self, t):
        """
        Compute the signal-to-noise ratio for a single timestep.
        """
        self.alphas_cumprod = self.alphas_cumprod.to(t.device)
        return self.alphas_cumprod[t] / (1 - self.alphas_cumprod[t])

    def _extract_into_tensor(self, arr, timesteps, broadcast_shape):
        """
        Extract values from a 1-D numpy array for a batch of indices.

        :param arr: the 1-D numpy array.
        :param timesteps: a tensor of indices into the array to extract.
        :param broadcast_shape: a larger shape of K dimensions with the batch
                                dimension equal to the length of timesteps.
        :return: a tensor of shape [batch_size, 1, ...] where the shape has K dims.
        """
        # res = th.from_numpy(arr).to(device=timesteps.device)[timesteps].float()
        arr = arr.to(timesteps.device)
        res = arr[timesteps].float()
        while len(res.shape) < len(broadcast_shape):
            res = res[..., None]
        return res.expand(broadcast_shape)
    
    def get_x_start(self, x_start_mean, std):
        '''
        Using the interpolating policy OR using the convolution policy...
        :param x_start_mean:
        :return:
        '''
        noise = th.randn_like(x_start_mean)
        assert noise.shape == x_start_mean.shape
        return (
             x_start_mean + std * noise
        )
class SiLU(nn.Module):
    def forward(self, x):
        return x * th.sigmoid(x)
def linear(*args, **kwargs):
    """
    Create a linear module.
    """
    return nn.Linear(*args, **kwargs)
class TrmEncoder(nn.Module):
    def __init__(self, config, dataset):
        super().__init__()

        self.n_layers = config['n_layers']
        self.n_heads = config['n_heads']
        self.hidden_size = config['hidden_size']
        self.inner_size = config['inner_size']
        self.hidden_dropout_prob = config['hidden_dropout_prob']
        self.attn_dropout_prob = config['attn_dropout_prob']
        self.hidden_act = config['hidden_act']
        self.layer_norm_eps = config['layer_norm_eps']
        self.initializer_range = config['initializer_range']
        self.lamb = config['lamb']

        self.position_embedding = nn.Embedding(4 * dataset.max_item_list_len, self.hidden_size) # 直接开适量的embedding足够使用即可
        self.timestep_embedding = nn.Embedding(config['steps'], config['hidden_size'])
        self.time_embed = nn.Sequential(
            linear(self.hidden_size, self.hidden_size * 4),
            SiLU(),
            linear(self.hidden_size * 4, self.hidden_size),
        )

        self.trm_encoder = TransformerEncoder(
            n_layers=self.n_layers,
            n_heads=self.n_heads,
            hidden_size=self.hidden_size,
            inner_size=self.inner_size,
            hidden_dropout_prob=self.hidden_dropout_prob,
            attn_dropout_prob=self.attn_dropout_prob,
            hidden_act=self.hidden_act,
            layer_norm_eps=self.layer_norm_eps
        )

        self.LayerNorm = nn.LayerNorm(self.hidden_size, eps=self.layer_norm_eps)
        self.dropout = nn.Dropout(self.hidden_dropout_prob)
        self.fn = nn.Linear(self.hidden_size,1)

        self.apply(self._init_weights)

    def get_attention_mask(self, item_seq, bidirectional=False):
        """Generate left-to-right uni-directional or bidirectional attention mask for multi-head attention."""
        attention_mask = (item_seq != 0)
        extended_attention_mask = attention_mask.unsqueeze(1).unsqueeze(2)  # torch.bool
        if not bidirectional:
            extended_attention_mask = torch.tril(extended_attention_mask.expand((-1, -1, item_seq.size(-1), -1)))
        extended_attention_mask = torch.where(extended_attention_mask, 0., -10000.)
        return extended_attention_mask
    
    def seq2seq_forward(self, item_seq, item_emb):
        mask = item_seq.gt(0)

        # 位置编码
        position_ids = torch.arange(item_seq.size(1), dtype=torch.long, device=item_seq.device)
        position_ids = position_ids.unsqueeze(0).expand_as(item_seq)
        position_embedding = self.position_embedding(position_ids)

        input_emb = item_emb + position_embedding
        input_emb = self.LayerNorm(input_emb)
        input_emb = self.dropout(input_emb)

        extended_attention_mask = self.get_attention_mask(item_seq)

        trm_output = self.trm_encoder(input_emb, extended_attention_mask, output_all_encoded_layers=True)
        output = trm_output[-1]

        return output
        

    def forward(self, item_seq, item_emb, x_t=None, ts=None):
        # mask = item_seq.gt(0)

        # # 位置编码
        # position_ids = torch.arange(item_seq.size(1), dtype=torch.long, device=item_seq.device)
        # position_ids = position_ids.unsqueeze(0).expand_as(item_seq)
        # position_embedding = self.position_embedding(position_ids)

        # # timestep编码
        # # timesteps = torch.tensor(ts, dtype=torch.int64, device=item_seq.device)
        # # # timesteps = timesteps.unsqueeze(1).expand_as(item_seq)
        # # # timesteps_embedding = self.timestep_embedding(timesteps)
        # # timesteps_embedding = self.time_embed(timestep_embedding(timesteps, self.hidden_size))
        # # timesteps_embedding = timesteps_embedding.unsqueeze(1).expand(-1, item_seq.shape[1], -1)

        # # 扩充x_t
        # # x_t = x_t.unsqueeze(1).expand(-1, item_seq.shape[1], -1)

        # input_emb = item_emb + position_embedding
        # input_emb = self.LayerNorm(input_emb)
        # input_emb = self.dropout(input_emb)

        # extended_attention_mask = self.get_attention_mask(item_seq)

        # trm_output = self.trm_encoder(input_emb, extended_attention_mask, output_all_encoded_layers=True)
        # output = trm_output[-1]

        # alpha = None
        # # alpha = self.fn(output).to(torch.double)
        # # alpha = torch.where(mask.unsqueeze(-1), alpha, -9e15)
        # # alpha = torch.softmax(alpha, dim=1, dtype=torch.float)
        # return alpha, output
        mask = item_seq.gt(0)

        # 位置编码
        position_ids = torch.arange(item_seq.size(1), dtype=torch.long, device=item_seq.device)
        position_ids = position_ids.unsqueeze(0).expand_as(item_seq)
        position_embedding = self.position_embedding(position_ids)

        # timestep编码
        timesteps = torch.tensor(ts, dtype=torch.int64, device=item_seq.device)
        # timesteps = timesteps.unsqueeze(1).expand_as(item_seq)
        # timesteps_embedding = self.timestep_embedding(timesteps)
        timesteps_embedding = self.time_embed(timestep_embedding(timesteps, self.hidden_size))
        timesteps_embedding = timesteps_embedding.unsqueeze(1).expand(-1, item_seq.shape[1], -1)

        # 扩充x_t
        x_t = x_t.unsqueeze(1).expand(-1, item_seq.shape[1], -1)

        input_emb = item_emb + position_embedding + self.lamb * (x_t + timesteps_embedding)
        # 修改只将原始序列末尾token添加噪声
        # src = self.lamb * (x_t + timesteps_embedding).unsqueeze(1)
        # temp = item_seq
        # last_token_index = (torch.sum(torch.where(temp > 0, 1, 0), dim=-1) - 1).unsqueeze(-1).unsqueeze(-1).expand(-1,1,input_emb.shape[-1])
        # input_emb = torch.scatter_add(input_emb, dim=1, index=last_token_index,src=src)
        # input_emb[:,-1,:] = input_emb[:,-1,:] + self.lamb * (x_t + timesteps_embedding)
        input_emb = self.LayerNorm(input_emb)
        input_emb = self.dropout(input_emb)

        extended_attention_mask = self.get_attention_mask(item_seq)

        trm_output = self.trm_encoder(input_emb, extended_attention_mask, output_all_encoded_layers=True)
        output = trm_output[-1]

        alpha = None
        # alpha = self.fn(output).to(torch.double)
        # alpha = torch.where(mask.unsqueeze(-1), alpha, -9e15)
        # alpha = torch.softmax(alpha, dim=1, dtype=torch.float)
        return alpha, output

    def _init_weights(self, module):
        """ Initialize the weights """
        if isinstance(module, (nn.Linear, nn.Embedding)):
            # Slightly different from the TF version which uses truncated_normal for initialization
            # cf https://github.com/pytorch/pytorch/pull/5617
            module.weight.data.normal_(mean=0.0, std=self.initializer_range)
        elif isinstance(module, nn.LayerNorm):
            module.bias.data.zero_()
            module.weight.data.fill_(1.0)
        if isinstance(module, nn.Linear) and module.bias is not None:
            module.bias.data.zero_()

def mean_flat(tensor):
    """
    Take the mean over all non-batch dimensions.
    """
    return tensor.mean(dim=list(range(1, len(tensor.shape))))

def betas_for_alpha_bar(num_diffusion_timesteps, alpha_bar, max_beta=0.999):
    """
    Create a beta schedule that discretizes the given alpha_t_bar function,
    which defines the cumulative product of (1-beta) over time from t = [0,1].

    :param num_diffusion_timesteps: the number of betas to produce.
    :param alpha_bar: a lambda that takes an argument t from 0 to 1 and
                      produces the cumulative product of (1-beta) up to that
                      part of the diffusion process.
    :param max_beta: the maximum beta to use; use values lower than 1 to
                     prevent singularities.
    """
    betas = []
    for i in range(num_diffusion_timesteps):
        t1 = i / num_diffusion_timesteps
        t2 = (i + 1) / num_diffusion_timesteps
        betas.append(min(1 - alpha_bar(t2) / alpha_bar(t1), max_beta))
    return np.array(betas)

def timestep_embedding(timesteps, dim, max_period=10000):
    """
    Create sinusoidal timestep embeddings.

    :param timesteps: a 1-D Tensor of N indices, one per batch element.
                      These may be fractional.
    :param dim: the dimension of the output.
    :param max_period: controls the minimum frequency of the embeddings.
    :return: an [N x dim] Tensor of positional embeddings.
    """

    half = dim // 2
    freqs = torch.exp(
        -math.log(max_period) * torch.arange(start=0, end=half, dtype=torch.float32) / half
    ).to(timesteps.device)
    args = timesteps[:, None].float() * freqs[None]
    embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
    if dim % 2:
        embedding = torch.cat([embedding, torch.zeros_like(embedding[:, :1])], dim=-1)
    return embedding


def betas_from_linear_variance(steps, variance, max_beta=0.999):
    alpha_bar = 1 - variance
    betas = []
    betas.append(1 - alpha_bar[0])
    for i in range(1, steps):
        betas.append(min(1 - alpha_bar[i] / alpha_bar[i - 1], max_beta))
    return np.array(betas)

def betas_for_alpha_bar(num_diffusion_timesteps, alpha_bar, max_beta=0.999):
    """
    Create a beta schedule that discretizes the given alpha_t_bar function,
    which defines the cumulative product of (1-beta) over time from t = [0,1].

    :param num_diffusion_timesteps: the number of betas to produce.
    :param alpha_bar: a lambda that takes an argument t from 0 to 1 and
                      produces the cumulative product of (1-beta) up to that
                      part of the diffusion process.
    :param max_beta: the maximum beta to use; use values lower than 1 to
                     prevent singularities.
    """
    betas = []
    for i in range(num_diffusion_timesteps):
        t1 = i / num_diffusion_timesteps
        t2 = (i + 1) / num_diffusion_timesteps
        betas.append(min(1 - alpha_bar(t2) / alpha_bar(t1), max_beta))
    return np.array(betas)

def betas_for_alpha_bar2(num_diffusion_timesteps, alpha_bar, max_beta=0.999):
    """
    Create a beta schedule that discretizes the given alpha_t_bar function,
    which defines the cumulative product of (1-beta) over time from t = [0,1].

    :param num_diffusion_timesteps: the number of betas to produce.
    :param alpha_bar: a lambda that takes an argument t from 0 to 1 and
                      produces the cumulative product of (1-beta) up to that
                      part of the diffusion process.
    :param max_beta: the maximum beta to use; use values lower than 1 to
                     prevent singularities.
    """
    betas = []
    betas.append(min(1-alpha_bar(0), max_beta))
    for i in range(num_diffusion_timesteps-1):
        t1 = i / num_diffusion_timesteps
        t2 = (i + 1) / num_diffusion_timesteps
        betas.append(min(1 - alpha_bar(t2) / alpha_bar(t1), max_beta))
    return np.array(betas)