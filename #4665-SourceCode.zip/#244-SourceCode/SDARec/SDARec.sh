#!/bin/bash

project_base_path=${1}
llm_base_path="${1}/LLM/"
dataset_path=${2}
ori_dataset=${3} # you could change it to "Amazon_Sports", "Amazon_Toys"
deepseek_api_key="YOUR DEEPSEEK API KEY"
gpu_id=3

# 基于Recbole框架预处理实验数据，并得到相关映射表
cd ${project_base_path}
python run_seq.py --dataset=${ori_dataset} --base_path=${project_base_path} --data_path=${dataset_path}

# 开始构造混合数据集，并使用LLM进行过滤
cd ${llm_base_path}

# 序列检索增强 + LLM过滤
CUDA_VISIBLE_DEVICES=${gpu_id} python main.py --ori_dataset=${ori_dataset} \
               --new_dataset_name=${new_dataset_name} \
               --update_datset_map='True' \
               --restart_request_llm='True' \
               --llm_task='jina_extract_seq' \
               --construct_hybrid_dataset='False' \
               --hybrid_dataset_mode=${hybrid_dataset_mode} \
               --deepseek_api_key=${deepseek_api_key} \
               --project_base_path=${project_base_path} \
               --llm_base_path=${llm_base_path} \
               --dataset_path=${dataset_path} \

# 数据集检索增强 + LLM过滤
CUDA_VISIBLE_DEVICES=${gpu_id} python main.py --ori_dataset=${ori_dataset} \
               --new_dataset_name=${new_dataset_name} \
               --update_datset_map='True' \
               --restart_request_llm='True' \
               --llm_task='jina_extract_dataset' \
               --construct_hybrid_dataset='False' \
               --hybrid_dataset_mode=${hybrid_dataset_mode} \
               --deepseek_api_key=${deepseek_api_key} \
               --project_base_path=${project_base_path} \
               --llm_base_path=${llm_base_path} \
               --dataset_path=${dataset_path} \

# 合并增强数据集与原数据集
ori_dataset="Amazon_Clothing"
new_dataset_name="Hybrid_Amazon_Clothing"
hybrid_dataset_mode="ori_dataset+filtered_seq+filtered_dataset"
CUDA_VISIBLE_DEVICES=${gpu_id} python main.py --ori_dataset=${ori_dataset} \
               --new_dataset_name=${new_dataset_name} \
               --update_datset_map='False' \
               --restart_request_llm='False' \
               --llm_task='jina_extract_dataset' \
               --construct_hybrid_dataset='True' \
               --hybrid_dataset_mode=${hybrid_dataset_mode} \
               --deepseek_api_key=${deepseek_api_key} \
               --project_base_path=${project_base_path} \
               --llm_base_path=${llm_base_path} \
               --dataset_path=${dataset_path} \
               --mode='sequential' \
