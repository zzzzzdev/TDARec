# 请求本地微调好的模型进行生成
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
import torch
import pandas as pd
from datasets import Dataset
import json
import deepspeed
import os
import pickle
import argparse
os.environ["TOKENIZERS_PARALLELISM"] = "false"

def load_data(args):
    if torch.distributed.get_rank() == 0:
        # 只有主进程（rank 0）读取文件
        with open(args.llm_base_path + f'Prompts/prompts_inputs.pkl', 'rb') as file:
            inputs, target_id = pickle.load(file)
        
        # 将数据打包成一个列表
        object_list = [inputs, target_id]
    else:
        # 其他进程初始化空列表
        object_list = [None, None]
    
    # 广播对象列表
    torch.distributed.broadcast_object_list(object_list, src=0)

    return object_list[0], object_list[1]

def save_data(args, result):
    if torch.distributed.get_rank() == 0:
        # 只有主进程（rank 0）写入文件
        with open(args.llm_base_path + f'llm_response/{args.new_dataset_name}/Llama/{args.llm_task}/llm_response.json','w') as file:
            json.dump(result, file)


def request_llama_parallel(args):
    ####################################################################### 加载预训练model tokenizer ################################################
    ################################################################################################################################################
    # 启用混合精度减少显存占用
    model = AutoModelForCausalLM.from_pretrained(pretrained_model_name_or_path=args.pretrained_model_name_or_path, torch_dtype="auto") 
    tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=args.pretrained_model_name_or_path)
    tokenizer.add_special_tokens({'pad_token': '[PAD]'}) # tokenizer和model的输入不匹配造成报错
    tokenizer.pad_token_id = tokenizer.eos_token_id
    model.resize_token_embeddings(len(tokenizer)) # tokenizer和model的输入不匹配造成报错，所以需要resize

    # 创建 DeepSpeed 推理引擎
    ds_engine = deepspeed.init_inference(
        model=model,
        config=args.deepspeed_config,
    )

    # 获取优化后的模型
    model = ds_engine.module

    # 将模型移动到 GPU（如果可用）
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    model.eval()

    ####################################################################### 加载请求GPT的prompts input ###############################################
    ################################################################################################################################################
    llm_inputs, target_ids = load_data(args)
    
    ####################################################################### model 推理 ##############################################################
    ################################################################################################################################################
    batch_size = args.Llama_batch_size  # 根据你的硬件资源调整批处理大小
    all_outputs = []
    all_target_id = []

    # 对所有提示进行编码
    inputs = tokenizer(llm_inputs, return_tensors="pt", padding=True, truncation=True, max_length= args.tokenizer_max_length).to(device)

    for i in range(0, len(llm_inputs), batch_size):
        batch = {k: v[i:i + batch_size].to(device) for k, v in inputs.data.items()}
        outputs = model.generate(
            **batch,
            max_length=args.Llama_output_max_length,
            temperature=0.95,
            top_p=0.95,
            do_sample=False # 为True会导致报错RuntimeError: probability tensor contains either inf, nan or element < 0, 但可能影响PPO性能
        )
        all_outputs.extend(outputs)
        all_target_id.extend(target_ids[i:i + batch_size])

    ####################################################################### dump model 返回文本 #####################################################
    ################################################################################################################################################
    # 解码生成的文本
    generated_texts = [tokenizer.decode(output, skip_special_tokens=True) for output in all_outputs]
    result = {str(k): v for k, v in zip(all_target_id, generated_texts)}

    # 保存数据
    save_data(args, result)


if __name__ == '__main__':
    #### 命令行参数 #### 
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', '-m', type=str, default='DuoRec', help='name of models')
    parser.add_argument('--dataset', '-d', type=str, default='Amazon_Toys', help='name of datasets')
    parser.add_argument('--project_base_path', type=str, default='/amax/home/zitong/Documents/DivRec/', help='default project base path')
    parser.add_argument('--llm_base_path', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/', help='default LLM base path')
    parser.add_argument('--dataset_path', type=str, default='/amax/home/zitong/Documents/All_Dataset/', help='dataset path')
    parser.add_argument('--update_datset_map', type=bool, default=True, help='is need to update datset map')
    parser.add_argument('--text_encode_model', type=str, default='jinaai/jina-embeddings-v3', help='use which model to encode the text')
    parser.add_argument('--request_LLM_api', type=bool, default=False, help='whether request LLM api or request local finetuned model')
    parser.add_argument('--llm_task', type=str, default='LLMFilterSubInterest', help='llm_task')

    ### 请求本地Llama参数
    parser.add_argument('--pretrained_model_name_or_path', type=str, default='/amax/home/zitong/Documents/LLMModels/finetuned-Llama-2-7b-chat-hf/finetuned-Llama', help='the path of Llama')
    parser.add_argument('--Llama_batch_size', type=int, default=8, help='Llamda inference batch size')
    parser.add_argument('--tokenizer_max_length', type=int, default=4096, help='Llamda inference batch size')
    parser.add_argument('--Llama_output_max_length', type=int, default=4096, help='Llama_output_max_length')
    parser.add_argument('--deepspeed_config', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/ds_config.json', help='deepspeed_config')

    ### 请求LLM API的设置
    parser.add_argument('--num_thread', type=int, default=16, help='the number of thread used to request llm')
    
    args, _ = parser.parse_known_args()

    ########################################## 请求LLM ###########################
    request_llama_parallel(args)



    