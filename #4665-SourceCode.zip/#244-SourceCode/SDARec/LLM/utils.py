import json
import pandas as pd
import requests
import torch
import pickle
from sentence_transformers import SentenceTransformer
import numpy as np
from tqdm import tqdm
from sklearn.metrics.pairwise import cosine_similarity
import logging
import os
import colorlog
from recbole.utils.utils import get_local_time, ensure_dir
from colorama import init
from collections import defaultdict
os.environ['http_proxy'] = "172.18.166.31:7899"
os.environ['https_proxy'] = os.environ['http_proxy']

def jina_extract_seq(args):
    '''
    利用Jina 模型从滑动窗口序列中抽取Top1相似的物品组成二元组, sample 数量大概10W
    '''
    with open(args.project_base_path + f'data/{args.ori_dataset}/interaction.json','r') as file:
        interaction = json.load(file)
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_embeddings.pkl','rb') as file:
        items_embeddings = pickle.load(file) # array

    max_sim_dict = {}
    for target, seqs in tqdm(interaction['target_seqs'].items(), desc='Construct jina extract tuple:'):
        max_sim_seqs = []
        for seq in seqs:
            temp_seq = np.array(list(map(lambda x: items_embeddings[int(x) - 2], seq))) 
            temp_target = np.array([items_embeddings[int(target) - 2]] * len(temp_seq))
            similarity_matrix = cosine_similarity(temp_seq, temp_target)[:, 0]
            k = 1
            # 找原始数据集topk
            if len(similarity_matrix) >= k:
                top_k_indices_unsorted = np.argpartition(similarity_matrix, -k)[-k:]
                top_k_indices_sorted = top_k_indices_unsorted[np.argsort(similarity_matrix[top_k_indices_unsorted])[::-1]]
                max_sim_item_id = seq[top_k_indices_sorted[k - 1]] # 相似度top2
                max_sim_seqs.append([max_sim_item_id, str(target)])
        max_sim_dict[str(target)] = max_sim_seqs

    # 存储返回的文件
    with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/jina_extract_seq/jina_extract_seq.json','w') as file:
        json.dump(max_sim_dict, file)
    
def jina_extract_dataset(args):
    '''
    利用Jina 模型从数据集中抽取Top1相似的物品组成二元组, sample 数量大概1W
    '''
    with open(args.project_base_path + f'data/{args.ori_dataset}/interaction.json','r') as file:
        interaction = json.load(file)
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_embeddings.pkl','rb') as file:
        items_embeddings = pickle.load(file) # array

    dataset_max_sim_dict = {}
    sim_matrix = cosine_similarity(items_embeddings)
    np.fill_diagonal(sim_matrix, -np.inf)
    for target_id in tqdm(range(len(items_embeddings)), desc='Construct jina extract tuple:'):
        max_sim_seqs = []
        max_sim_item_id = int(np.argmax(sim_matrix[int(target_id)])) + 2
        max_sim_seqs.append([max_sim_item_id, str(target_id + 2)])
        dataset_max_sim_dict[str(target_id + 2)] = max_sim_seqs

    # 存储返回的文件
    with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/jina_extract_dataset/jina_extract_dataset.json','w') as file:
        json.dump(dataset_max_sim_dict, file)

def filter_jina_extract(args):
    # 加载原始二元组
    with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/{args.llm_task}/{args.llm_task}.json','r') as file:
        ori_jina_extract_tuple = json.load(file)
    # 加载 llm输出的 label
    with open(args.llm_base_path + f'llm_response/{args.new_dataset_name}/{args.llm_task}/resolve_llm_{args.llm_task}.json','r') as file:
        llm_filter_jina_extract_label = json.load(file)
    
    # 过滤 二元组
    filtered_jina_extract_tuple = defaultdict(list)
    for target_id, interest_list in tqdm(ori_jina_extract_tuple.items(), desc='Filter_jina_extract'):
        for i in range(len(interest_list)):
            if (target_id not in llm_filter_jina_extract_label.keys()) or (str(i) not in llm_filter_jina_extract_label[target_id].keys()) or ('No' not in llm_filter_jina_extract_label[target_id][str(i)]):
                filtered_jina_extract_tuple[target_id].append(interest_list[i])

    # dump 过滤后的二元组
    with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/{args.llm_task}/filtered_{args.llm_task}.json','w') as file:
        json.dump(filtered_jina_extract_tuple, file)

def load_scl_views(args):
    '''
    加载 scl 视图
    '''
    # 加载scl views信息
    with open(args.project_base_path + f'data/{args.ori_dataset}/interaction.json', 'r') as file:
        interaction = json.load(file)
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json', 'r') as file:
        item_map = json.load(file)

    target_title_list = []
    target_id_list = []
    interaction_sequences_list = []
    target_seqs = interaction['target_seqs']
    for target_id, same_target_seq in target_seqs.items():
        target_title = item_map['token_attribute'][item_map['id_token'][target_id]]['title']
        interaction_sequences = [list(map(lambda x: item_map['token_attribute'][item_map['id_token'][str(x)]]['title'], seq)) for seq in same_target_seq]

        target_title_list.append(target_title)
        target_id_list.append(target_id)
        interaction_sequences_list.append(interaction_sequences)

    return target_id_list, target_title_list, interaction_sequences_list

def construct_prompts(args):
    '''
    构建LLM的输入prompts
    '''
    with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/{args.llm_task}/{args.llm_task}.json','r') as file:
        subInterests = json.load(file)
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json', 'r') as file:
        item_map = json.load(file)

    prompt_inputs = []
    target_ids = []
    # 记录interest在该target list中的index
    index = []
    for target_id, interests in tqdm(subInterests.items(), desc='Construct Prompts:'):
        for i in range(len(interests)):
            target_title = item_map['token_attribute'][item_map['id_token'][target_id]]['title']
            interest = [item_map['token_attribute'][item_map['id_token'][str(interests[i][0])]]['title'] , target_title]
            prompt = f"""
            ## Role 
            You are an expert in analyzing and capturing user preferences according to historical behaviors.

            ## Task
            Given some <## Pairs>, please help me to do the following tasks in order:
            Step 1: Please use world knowledge (e.g., item attributes, item title, item brand, item price and so on) to analyze and summerize the attributes of each item in each Pair.
            Step 2: Please use world knowledge (e.g., item attributes, item title, item brand, item price and so on), analyzed attributes in Step 1 to reason and analyze whether the user will continue to purchase the second item if the user has already purchased the first item in each pair?
            Step 3: Please summerize the answer in Step 2, and only response 'Yes' or 'No'.

            ## Pairs\n
            {interest}

            ## Requirements
                ###(1) The <## Pairs> only contains item title. Please use world knowledge (e.g., item attributes, item title, item brand, item price and so on) about the items to enhance the <## Task>.
                ###(2) Please do the <## Task> for each Pairs in <## Pairs>.
                ###(3) You MUST do the <## Task> step by step carefully for each user. The response need to follow the <## Response Format>.
            
            ## Response Format
                You MUST do the <## Task> step by step carefully for each pair. A pair completes all steps before moving on to the next pair.
                **Step 1: Summerize each item's attributes:
                **Step 2: Analyze whther to purchase the second item:
                **Step 3: Response 'Yes' or 'No':
            """
            # 三者配对，目前是为了匹配llm输入输出
            prompt_inputs.append(prompt)
            target_ids.append(target_id)
            index.append(i)


    # 存储需要请求的prompts
    with open(args.llm_base_path + f'Prompts/{args.new_dataset_name}/{args.llm_task}/{args.llm_task}_prompts_inputs.pkl','wb') as file:
        pickle.dump((prompt_inputs, target_ids, index), file)


def load_model(args):
    model = SentenceTransformer(args.text_encode_model, trust_remote_code=True)
    return model

def encode_item_corpus(args):
    '''
    使用jina模型编码物品语料
    '''
    model = load_model(args)
    ## 加载数据集所有物品的title信息，编码获得corpus embedding
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json', 'r') as file:
        item_data = json.load(file)
    corpus_title = list(item_data['id_title'].values()) # 注意此处没有计算PAD 和 MASK 因此会有2偏置，第0个corpus的item id 是2
    corpus_title = [str(title) for title in corpus_title]
    embeddings = model.encode(corpus_title, task="text-matching")

    # dump corpus的embedding
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_embeddings.pkl','wb') as file: # shape [18357, 1024]
        pickle.dump(embeddings, file)


def encode_llm_output(args):
    '''
    使用jina编码llm输出语料
    '''
    model = load_model(args)
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_embeddings.pkl','rb') as file:
        item_embeddings = pickle.load(file)

    item_embeddings = torch.tensor(item_embeddings, device = model.device, dtype=torch.bfloat16)
    # 加载LLM输出，以进行encode编码,json格式，target item是key，值是二维列表，表示新生成的5 个 sequence
    with open(args.llm_base_path + f'llm_response/{args.new_dataset_name}/resolve_llm.json', 'r') as file:
        resolve_llm = json.load(file) # dict ,key 是target item, value 是生成的二维list, 每个元素表示一个序列，一个序列有多个物品。
    
    new_data = {} # 存储rounding之后的结果
    for target, five_seqs in tqdm(resolve_llm.items(), desc='Using jina to encode llm output to id:'):
        seqs_id_list = []
        for one_seq in five_seqs:
            one_seq_id_list = []
            query_embeddings = model.encode(one_seq, convert_to_tensor=True) # 一次性得到整个序列的embedding输出
            # Find the closest 5 sentences of the corpus for each query sentence based on cosine similarity
            top_k = 1
            for inx, item in enumerate(one_seq):
                query_embedding = query_embeddings[inx]
                # We use cosine-similarity and torch.topk to find the highest 5 scores
                similarity_scores = model.similarity(query_embedding, item_embeddings)[0]
                scores, indices = torch.topk(similarity_scores, k=top_k)
                """
                # Alternatively, we can also use util.semantic_search to perform cosine similarty + topk
                hits = util.semantic_search(query_embedding, corpus_embeddings, top_k=5)
                hits = hits[0]      #Get the hits for the first query
                for hit in hits:
                    print(corpus[hit['corpus_id']], "(Score: {:.4f})".format(hit['score']))
                """
                rounding_item_id = indices[0].item() + 2
                one_seq_id_list.append(rounding_item_id)
            # 每一个seq末尾增加一个target
            one_seq_id_list.append(target)
            seqs_id_list.append(one_seq_id_list)
        
        new_data[target] = seqs_id_list
    
    with open(args.llm_base_path + f'llm_response/{args.new_dataset_name}/resolve_llm_id.json','w') as file:
        json.dump(new_data, file)

def find_scl_views(args):
    '''
    根据已有的资料，寻找监督对比视图。 目前不需要使用了，已经有了监督对比视图。
    '''
    with open(args.project_base_path + f'data/{args.ori_dataset}/interaction.json', 'r') as file:
        interaction_data = json.load(file)
    inter_seq = interaction_data['user_seq']
    inter_target = interaction_data['user_target']

    df = pd.DataFrame(list(inter_target.items()), columns=['user_id','target'])
    target_user_dict = df.groupby('target')['user_id'].apply(list).to_dict()
    interaction_data['target_user'] = target_user_dict # key 是target item id, value 是对应user id # 相同的一共有12000左右。所以需要请求LLM 12000次。
    with open(args.project_base_path + f'data/{args.ori_dataset}/interaction.json', 'w') as file:
        json.dump(interaction_data, file)


def construct_small_dataset():
    '''
    构建小的数据集
    '''
    df = pd.read_csv('/amax/home/zitong/Documents/All_Dataset/Amazon_Toys/Amazon_Toys.inter', sep='\t')
    # 随机抽样2000行作为新创建的数据集
    new_df = df.sample(n=800000, random_state=42)
    new_df.to_csv(path_or_buf='/amax/home/zitong/Documents/All_Dataset/Amazon_Toys_small/Amazon_Toys_small.inter', sep='\t', index=False)


def print_API_balance():
    url = "https://api.deepseek.com/user/balance"
    api_key = "<YOUR API TOKEN>" # 要查询的API-Key

    headers = {
    "Accept": "application/json",
    "Authorization": f"Bearer {api_key}"
    }

    response = requests.request("GET", url, headers=headers)

    print(response.text)

log_colors_config = {
    'DEBUG': 'cyan',
    'WARNING': 'yellow',
    'ERROR': 'red',
    'CRITICAL': 'red',
}


def init_logger(args):
    """
    A logger that can show a message on standard output and write it into the
    file named `filename` simultaneously.
    All the message that you want to log MUST be str.

    Args:
        config (Config): An instance object of Config, used to record parameter information.

    Example:
        >>> logger = logging.getLogger(config)
        >>> logger.debug(train_state)
        >>> logger.info(train_result)
    """
    init(autoreset=True)

    LOGROOT = args.log_path
    LOGROOT += f'{args.ori_dataset}/{args.new_dataset_name}-{get_local_time()}/'
    dir_name = os.path.dirname(LOGROOT)
    ensure_dir(dir_name)

    logfilename = 'log.txt'

    logfilepath = os.path.join(LOGROOT, logfilename)

    filefmt = "%(asctime)-15s %(levelname)s  %(message)s"
    filedatefmt = "%a %d %b %Y %H:%M:%S"
    fileformatter = logging.Formatter(filefmt, filedatefmt)

    sfmt = "%(log_color)s%(asctime)-15s %(levelname)s  %(message)s"
    sdatefmt = "%d %b %H:%M"
    sformatter = colorlog.ColoredFormatter(sfmt, sdatefmt, log_colors=log_colors_config)
    if args.log_state is None or args.log_state.lower() == 'info':
        level = logging.INFO
    elif args.log_state.lower() == 'debug':
        level = logging.DEBUG
    elif args.log_state.lower() == 'error':
        level = logging.ERROR
    elif args.log_state.lower() == 'warning':
        level = logging.WARNING
    elif args.log_state.lower() == 'critical':
        level = logging.CRITICAL
    else:
        level = logging.INFO
    fh = logging.FileHandler(logfilepath)
    fh.setLevel(level)
    fh.setFormatter(fileformatter)

    sh = logging.StreamHandler()
    sh.setLevel(level)
    sh.setFormatter(sformatter)

    logging.basicConfig(level=level, handlers=[fh, sh])

def mk_dirs(args):
    path1 = args.dataset_path + 'Hybrid_Datasets/' + args.new_dataset_name + '_' + args.hybrid_dataset_mode
    path2 = args.project_base_path + 'data/' + args.ori_dataset + '/'
    path3 = args.project_base_path + 'data/' + args.new_dataset_name + '/JinaExtractSubInterest/jina_extract_dataset/'
    path4 = args.project_base_path + 'data/' + args.new_dataset_name + '/JinaExtractSubInterest/jina_extract_seq/'
    path5 = args.llm_base_path + 'llm_response/' + args.new_dataset_name + '/jina_extract_seq/'
    path6 = args.llm_base_path + 'llm_response/' + args.new_dataset_name + '/jina_extract_dataset/'
    path7 = args.llm_base_path + 'Prompts/' + args.new_dataset_name + '/jina_extract_dataset/'
    path8 = args.llm_base_path + 'Prompts/' + args.new_dataset_name + '/jina_extract_seq/'
    path9 = args.llm_base_path + 'log/' + args.ori_dataset + '/'
    necessary_dirs_list = [path1, path2, path3, path4, path5, path6, path7, path8, path9]
    for path in necessary_dirs_list:
        if not os.path.exists(path):
            os.makedirs(path)

