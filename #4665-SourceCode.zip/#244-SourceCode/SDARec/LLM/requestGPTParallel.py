import threading
import queue
import time
import requests
import typing
import json
from tqdm import tqdm
import os
from collections import defaultdict
import pickle
from logging import getLogger
# os.environ['http_proxy'] = "172.18.166.31:7899"
# os.environ['https_proxy'] = os.environ['http_proxy']
os.environ['http_proxy'] = ""
os.environ['https_proxy'] = os.environ['http_proxy']

# 创建一个队列对象
result_queue = queue.Queue()

# 记录fail的target item id
fail_target_list = []

logger = getLogger()

def siliconflow_request_chat(api_key: str, 
                             model: str, 
                             messages: typing.List[dict], 
                             timeout: int = 200, 
                             *, 
                             max_tokens: int = 4000, 
                             stop: typing.Union[typing.List[str], None] = None, 
                             temperature: float = 1.0, 
                             top_p: float = 1.0, 
                             top_k: int = 50, 
                             frequency_penalty: float = 0.0, 
                             n: int = 1, 
                             **kargs
                             )-> dict:
    '''
    访问硅基流动平台的对话API。
    api_key: 使用的API_Key
    model: 使用的模型名称
    messages: 符合OpenAI调用格式的消息内容
    timeout: 单次网络访问最大时间限制
    max_tokens: 最大生成词元数
    stop: 停止标记，字符串列表格式
    temperature: 采样温度，取值为[0, 2.0]
    top_p: 采样概率累计，取值为(0, 1.0]
    top_k: 采样选取范围
    frequency_penalty: 频率惩罚，正值会降低模型在一行中重复使用已经频繁出现的词的可能性，取值为[-2.0, 2.0]
    n: 生成样本数量
    '''

    url = "https://api.siliconflow.cn/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
        }

    payload = { # 参数设置
        "model": model,
        "messages": messages,
        "stream": False,
        "max_tokens": max_tokens,
        "stop": stop,
        "temperature": temperature,
        "top_p": top_p,
        "top_k": top_k,
        "frequency_penalty": frequency_penalty,
        "n": n,
        "response_format": {"type": "text"}
        }

    response = requests.request("POST", url, json=payload, headers=headers, timeout=timeout)
    if response.status_code != 200:
        response.raise_for_status()

    return response.json()

def deepseek_request_chat(api_key: str, 
                          model: str, 
                          messages: typing.List[dict], 
                          timeout: int = 100, 
                          *, 
                          max_tokens: int = 4000, 
                          stop: typing.Union[typing.List[str], None] = None, 
                          temperature: float = 1.0, 
                          top_p: float = 1.0, 
                          frequency_penalty: float = 0.0, 
                          presence_penalty: float = 0.0, 
                          n: int = 1, 
                          **kargs
                          )-> dict:
    '''
    访问deepseek平台的对话API。
    api_key: 使用的API_Key
    model: 使用的模型名称
    messages: 符合OpenAI调用格式的消息内容
    timeout: 单次网络访问最大时间限制
    max_tokens: 最大生成词元数
    stop: 停止标记，字符串列表格式
    temperature: 采样温度，取值为[0, 2.0]
    top_p: 采样概率累计，取值为(0, 1.0]
    frequency_penalty: 频率惩罚，正值会降低模型在一行中重复使用已经频繁出现的词的可能性，取值为[-2.0, 2.0]
    presence_penalty: 话题新鲜度，较高的值更可能扩展到新话题，取值为[-2.0, 2.0]
    n: 生成样本数量
    '''

    url = "https://api.deepseek.com/chat/completions"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
        }

    payload = { # 参数设置
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "stop": stop,
        "temperature": temperature,
        "top_p": top_p,
        "frequency_penalty": frequency_penalty,
        "presence_penalty": presence_penalty,
        "n": n
        }

    response = requests.request("POST", url, json=payload, headers=headers, timeout=timeout)
    if response.status_code != 200:
        response.raise_for_status()

    return response.json()

def request_Llama(llm_one_input, api_key):
    model = "meta-llama/Meta-Llama-3.1-8B-Instruct" # 模型名称
    messages = [ # 对话内容
            {
                "role": "user",
                "content": llm_one_input,
            }
        ]
    try:
        content = siliconflow_request_chat(api_key, model, messages) # 可根据需要调整其他参数
    except requests.exceptions.Timeout:
        print("请求超时！")
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP错误: {http_err}")
    except requests.exceptions.RequestException as e:
        print(f"请求错误: {e}")
    return content

def request_Qwen(llm_one_input, api_key):
    model = "Qwen/Qwen2.5-32B-Instruct" # 模型名称
    messages = [ # 对话内容
            {
                "role": "user",
                "content": llm_one_input,
            }
        ]

    try:
        content = siliconflow_request_chat(api_key, model, messages) # 可根据需要调整其他参数
    except requests.exceptions.Timeout:
        print("请求超时！")
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP错误: {http_err}")
    except requests.exceptions.RequestException as e:
        print(f"请求错误: {e}")
    return content

def request_DeepSeek(llm_one_input, api_key):
    model = "deepseek-chat" # 模型名称
    messages = [ # 对话内容
        {
            "role": "user",
            "content": llm_one_input,
        }
    ]
    try:
        content = deepseek_request_chat(api_key, model, messages) # 可根据需要调整其他参数
    except requests.exceptions.Timeout:
        raise
    except requests.exceptions.HTTPError as http_err:
        raise
    except requests.exceptions.RequestException as e:
        raise
    return content

# 定义一个生产者函数，模拟多个线程将数据放入队列
def producer(input_queue, result_queue, args):
    while True:
        try:
            llm_one_input, target_id, index = input_queue.get(timeout=1)
            content = request_DeepSeek(llm_one_input, args.deepseek_api_key)
            content['target_id'] = str(target_id)
            content['index'] = str(index)
            result_queue.put(content)
            print(input_queue.qsize())
        except queue.Empty:
            break
        except requests.exceptions.Timeout:
            fail_target_list.append(target_id)
        except requests.exceptions.HTTPError as http_err:
            fail_target_list.append(target_id)
        except requests.exceptions.RequestException as e:
            fail_target_list.append(target_id)

# 定义一个消费者函数，从队列中取出数据并写入文件
def consumer(result_queue, args):
    request_dict = defaultdict(dict)
    while True:
        try:
            data = result_queue.get(timeout=1000)  # 设置超时时间，防止无限阻塞 30应该会有生产者请求到结果了
            if data is None:
                # 如果收到 None，表示所有生产者已经完成
                with open(args.llm_base_path + f'llm_response/{args.new_dataset_name}/{args.llm_task}/llm_response_{args.llm_task}.json', 'w') as file:
                    json.dump(request_dict, file)
                break
            # 抽取所有结果，dump到文件中
            target_id = data['target_id']
            index = data['index']
            # 相同target item可能被分批次请求，所以需要append
            request_dict[target_id][index] = data
            result_queue.task_done()
        except queue.Empty:
            continue
    logger.info('Write LLM\'s response to the path: ' + args.llm_base_path + f'llm_response/{args.new_dataset_name}/{args.llm_task}/llm_response_{args.llm_task}.json')

def request_llm_parallel(args):
    with open(args.llm_base_path + f'Prompts/{args.new_dataset_name}/{args.llm_task}/{args.llm_task}_prompts_inputs.pkl','rb') as file:
        llm_inputs, target_ids, index = pickle.load(file)

    input_queue = queue.Queue()
    for i in range(len(llm_inputs[:5])): # 先使用前10个测试代码
        input_queue.put((llm_inputs[i], target_ids[i], index[i]))

    # 创建多个生产者线程
    producer_threads = []
    for i in range(args.num_thread):
        thread = threading.Thread(target=producer, args=(input_queue, result_queue, args))
        producer_threads.append(thread)
        thread.start()

    # 创建一个消费者线程
    consumer_thread = threading.Thread(target=consumer, args=(result_queue, args))
    consumer_thread.start()

    # 等待所有生产者线程完成
    for thread in producer_threads:
        thread.join()

    # 向队列发送结束信号
    result_queue.put(None)

    # 等待消费者线程完成
    consumer_thread.join()

    logger.info("All threads have finished writing.")
    logger.info(f'Fail target item id: {fail_target_list}')

if __name__ == '__main__':
    num_threads = 16