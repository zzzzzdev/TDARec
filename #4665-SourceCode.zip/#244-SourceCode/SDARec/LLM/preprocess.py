import os
import random
import tqdm
import html
from collections import defaultdict
import numpy as np
import json
import gzip
from string import ascii_letters, digits, punctuation, whitespace
import pandas as pd
import math

def parse(x):
    x = html.unescape(x)
    x = x.replace("“", "\"")
    x = x.replace("”", "\"")
    x = x.replace("‘", "'")
    x = x.replace("’", "'")
    x = x.replace("–", "-")
    x = x.replace("\n", " ")
    x = x.replace("\r", " ")
    x = x.replace("…", "")
    x = x.replace("‚", ",")
    x = x.replace("´", "'")
    x = x.replace("&ndash;", "-")
    x = x.replace("&lt;", "<")
    x = x.replace("&gt;", ">")
    x = x.replace("&amp;", "&")
    x = x.replace("&quot;", "\"")
    x = x.replace("&nbsp;", " ")
    x = x.replace("&copy;", "©")
    x = x.replace("″", "\"")
    x = x.replace("【", "[")
    x = x.replace("】", "]")
    x = x.replace("—", "-")
    x = x.replace("−", "-")
    return x

def filter_title(x):
    if isinstance(x , float) and math.isnan(x):
        return "unknown title"
    x = parse(x)
    for ci in [127, 174, 160, 170, 8482, 188, 162, 189, 8594, 169, 235, 168, 957, 12288, 8222, 179, 190, 173, 186, 8225]:
        x = x.replace(chr(ci), " ")
    while "  " in x:
        x = x.replace("  ", " ")
    x = x.strip()
    for letter in x:
        if letter not in ascii_letters + digits + punctuation + whitespace:
            return ascii_letters + digits + punctuation + whitespace # Delete Flag
    if len(set(x) & set(ascii_letters)) == 0 or len(x) < 3:
        return ascii_letters + digits + punctuation + whitespace # Delete Flag
    if len(x) > 150:
        x = x[:150]
        x = " ".join(x.strip().split(" ")[:-1])
        while x[-1] not in ascii_letters + digits:
            x = x[:-1]
    return x

def convert_category(x):
    if isinstance(x , float) and math.isnan(x):
        return 'unknown category'
    x = x.split(',')
    x = [parse(cate.strip("‘’' ")) for cate in x]
    x = [x[0].strip()] if len(x) else ['unknown category']
    return x

def convert_brand(x):
    if (isinstance(x, float) and math.isnan(x)):
        return 'unknown brand'
    x = parse(x)
    for ci in [127, 174, 160, 170, 8482, 188, 162, 189, 8594, 169, 235, 168, 957, 12288, 8222, 179, 190, 173, 186, 8225]:
        x = x.replace(chr(ci), " ")
    while "  " in x:
        x = x.replace("  ", " ")
    x = x.strip()
    for letter in x:
        if letter not in ascii_letters + digits + punctuation + whitespace:
            return ascii_letters + digits + punctuation + whitespace # Delete Flag
    if len(set(x) & set(ascii_letters)) == 0:
        return ascii_letters + digits + punctuation + whitespace # Delete Flag
    if len(x) > 150:
        x = x[:150]
        x = " ".join(x.strip().split(" ")[:-1])
        while x[-1] not in ascii_letters + digits:
            x = x[:-1]
    if 'abcdefg' in x:
        x = 'unknown brand'
    return x

def process_meta_data(args, item_token_attribute):
    datas = {}
    if 'Amazon' in args.ori_dataset:
        for token, info in item_token_attribute.items():
            new_info = {'categories': convert_category(info['categories']),
                        'brand': convert_brand(info['brand']),
                        'title': filter_title(info['title'])}
            if new_info['title'] == 'EMINEM SHOW':
                continue
            datas[token] = new_info
    elif args.ori_dataset.lower() == 'yelp':
        # 对于yelp 标题含有信息较少，拼接分类和标题名字
        for token, info in item_token_attribute.items():
            new_info = {'categories': convert_category(info['categories']),
                        'title': filter_title(info['title']) + ' '.join(convert_category(info['categories']))}
            if new_info['title'] == 'EMINEM SHOW':
                continue
            datas[token] = new_info
    else:
        raise NotImplementedError

    return datas

def convert_recbole_meta_data(args, path):
    meta_data = pd.read_csv(path, delimiter='\t')
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json','r') as file:
        item_map = json.load(file)

    token = set(item_map['token_id'].keys())
    intersection_token = meta_data[meta_data['item_id:token'].isin(token)]

    intersection_token.set_index('item_id:token', inplace=True)
    # 兼容Amazon 和 yelp 数据集
    if 'Amazon' in args.ori_dataset:
        intersection_token = intersection_token[['title:token','brand:token','categories:token_seq']]
        intersection_token = intersection_token.rename(columns={'title:token': 'title', 'brand:token': 'brand', 'categories:token_seq':'categories'})
    elif args.ori_dataset.lower() == 'yelp':
        intersection_token = intersection_token[['item_name:token_seq','categories:token_seq']]
        intersection_token = intersection_token.rename(columns={'item_name:token_seq': 'title', 'categories:token_seq': 'categories'})
    else:
        raise NotImplementedError
    
    meta_data_dict = intersection_token.to_dict(orient='index')

    item_map['token_attribute'] = meta_data_dict
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json','w') as file:
        json.dump(item_map, file)

def process_meta_all(args):
    path = args.dataset_path + f'{args.ori_dataset}/{args.ori_dataset}.item'
    convert_recbole_meta_data(args, path)

    ### 清洗meta数据
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json','r') as file:
        item_data = json.load(file)
    item_token_attribute = item_data['token_attribute']
    new_item_token_attribute = process_meta_data(args, item_token_attribute)
    item_data['token_attribute'] = new_item_token_attribute

    ### 生成id_title映射
    item_id_token = item_data['id_token']
    item_id_title = {}
    for key, value in item_id_token.items():
        if value in ['[PAD]','[MASK]']:
            continue
        item_id_title[key] = item_token_attribute[value]['title']
    item_data['id_title'] = item_id_title
    with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json','w') as file:
        json.dump(item_data, file)


if __name__ == '__main__':
    # #### 加载Recbole的item文件,并抽取出meta信息
    path = '/amax/home/zitong/Documents/All_Dataset/Amazon_Sports/Amazon_Sports.item'
    # convert_recbole_meta_data(path)

    # ### 清洗meta数据
    # with open('/amax/home/zitong/Documents/DivRec/data/Amazon_Sports/item_map.json','r') as file:
    #     item_data = json.load(file)
    # item_token_id = item_data['token_id']
    # item_token_attribute = item_data['token_attribute']
    # new_item_token_attribute = process_meta_data(item_token_id, item_token_attribute)
    # item_data['token_attribute'] = new_item_token_attribute
    # ### 生成id_title映射
    # item_id_token = item_data['id_token']
    # item_id_title = {}
    # for key, value in item_id_token.items():
    #     if value in ['[PAD]','[MASK]']:
    #         continue
    #     item_id_title[key] = str(item_token_attribute[value]['title']) # 务必保证是字符串，否则encoder tokenization 报错
    # item_data['id_title'] = item_id_title
    # with open('/amax/home/zitong/Documents/DivRec/data/Amazon_Sports/item_map.json','w') as file:
    #     json.dump(item_data, file)