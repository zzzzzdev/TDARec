# 后处理GPT返回的代码，更新传统推荐模型的数据集
import pandas as pd
import json
import re
from tqdm import tqdm
import argparse
from logging import getLogger
from collections import defaultdict
logger = getLogger()

def resolve_llm_output(args):
    '''
    LLM输出了整个json文本, 需要抽取出有效的信息。抽取出生成的序列，组织起来
    '''
    resolve_llm_dict = defaultdict(dict)

    # 抽取llm的输出，为下游文本embedding做准备
    with open(args.llm_base_path + f'llm_response/{args.new_dataset_name}/{args.llm_task}/llm_response_{args.llm_task}.json', 'r') as file:
        llm_response = json.load(file)
    logger.info('Load LLM\'s response from ' + args.llm_base_path + f'llm_response/{args.new_dataset_name}/{args.llm_task}/llm_response_{args.llm_task}.json')
    
    for target_id, response_dict in tqdm(llm_response.items(), desc='Resolve_llm_output:'):
        ###################################################### 需要根据llm的输出做对应的解析修改 ###################################################### 
        for index, response in response_dict.items():
            effective_output = response['choices'][0]['message']['content']
            answer = effective_output.split('\n')[-1].strip(' -\n*')
            resolve_llm_dict[target_id][index] = answer

    # dump存储供jina文本embedding使用
    with open(args.llm_base_path + f'llm_response/{args.new_dataset_name}/{args.llm_task}/resolve_llm_{args.llm_task}.json','w') as file:
        json.dump(resolve_llm_dict, file)
    logger.info('Dump resolved LLM\'s response to the path: ' + args.llm_base_path + f'llm_response/{args.new_dataset_name}/{args.llm_task}/resolve_llm_{args.llm_task}.json')

def construct_hybrid_dataset(args):
    '''
    jina将文本转化成了id，需要将id转化成asin编码，并构造新的数据集。
    '''
    if args.mode == 'sequential':
        with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json','r') as file:
            item_map = json.load(file)

        # 选择给定的数据集混合模式
        if args.hybrid_dataset_mode == 'ori_dataset+filtered_seq+filtered_dataset':
            with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/jina_extract_seq/filtered_jina_extract_seq.json','r') as file:
                filtered_jina_extract_seq = json.load(file)
            with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/jina_extract_dataset/filtered_jina_extract_dataset.json','r') as file:
                filtered_jina_extract_dataset = json.load(file)
            # 因为dataset和seq的数据集key是一样的，所以将key施加一个偏置，保证不重复
            filtered_jina_extract_dataset = {str(int(k) + 30000):v for k, v in filtered_jina_extract_dataset.items()}
            filtered_jina_extract_seq.update(filtered_jina_extract_dataset)
            new_added_data = filtered_jina_extract_seq
        elif args.hybrid_dataset_mode == 'ori_dataset+seq+dataset':
            with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/jina_extract_seq/jina_extract_seq.json','r') as file:
                jina_extract_seq = json.load(file)
            with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/jina_extract_dataset/jina_extract_dataset.json','r') as file:
                jina_extract_dataset = json.load(file)
            # 因为dataset和seq的数据集key是一样的，所以将key施加一个偏置，保证不重复
            jina_extract_dataset = {str(int(k) + 30000):v for k, v in jina_extract_dataset.items()}
            jina_extract_seq.update(jina_extract_dataset)
            new_added_data = jina_extract_seq
        elif args.hybrid_dataset_mode == 'ori_dataset+filtered_dataset':
            with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/jina_extract_dataset/filtered_jina_extract_dataset.json','r') as file:
                filtered_jina_extract_dataset = json.load(file)
            # 因为dataset和seq的数据集key是一样的，所以将key施加一个偏置，保证不重复
            new_added_data = filtered_jina_extract_dataset
        elif args.hybrid_dataset_mode == 'ori_dataset+filtered_seq':
            with open(args.project_base_path + f'data/{args.new_dataset_name}/JinaExtractSubInterest/jina_extract_seq/filtered_jina_extract_seq.json','r') as file:
                filtered_jina_extract_seq = json.load(file)
            # 因为dataset和seq的数据集key是一样的，所以将key施加一个偏置，保证不重复
            new_added_data = filtered_jina_extract_seq
        else:
            raise NotImplementedError

        all_user_id_list = []
        all_item_id_list = []
        all_rating_list = []
        all_timestamp_list = []

        for target_id, new_inter_data in tqdm(new_added_data.items(), desc='Construct Hybrid Dataset:'):
            # 序列 e.g. [[123,12,3,12,45,3,75],[3,232,4,56,788,3]], 每个list最后一个是target item，并转化成asin编码
            item_id_token = item_map['id_token'] # 转化成asin编码
            new_inter_data = [list(map(lambda x: item_id_token[str(x)], inter_data)) for inter_data in new_inter_data] # [[],[],[]]
            # 兼容recbole数据集
            user_id_list = []
            item_id_list = []
            rating_list = []
            timestamp_list = []
            start_timestamp = 1546264900 # 为了兼容yelp数据集
            for idx, new_data in enumerate(new_inter_data):
                # 如果新序列的长度不够6，则PAD到6
                if len(new_data) < 4: # 不可以直接添加[PAD],此处添加的[PAD]和填充的[PAD] 在item id映射的时候不相同
                    new_data.extend(['[HOLDER]'] * (4 - len(new_data)))
                new_data.extend(['[HOLDER]'] * 2)
                pseudo_user_token = f'Amazon_pseudo_user_{target_id}_{idx}'
                user_id_list.extend([pseudo_user_token] * len(new_data))
                item_id_list.extend(new_data)
                rating_list.extend([5.0] * len(new_data))
                timestamp_list.extend([start_timestamp + i for i in range(len(new_data))])
            
            all_user_id_list.extend(user_id_list)
            all_item_id_list.extend(item_id_list)
            all_rating_list.extend(rating_list)
            all_timestamp_list.extend(timestamp_list)
        
        new_data_dict = {}
        new_data_dict['user_id:token'] = all_user_id_list
        new_data_dict['item_id:token'] = all_item_id_list
        new_data_dict['rating:float'] = all_rating_list
        new_data_dict['timestamp:float'] = all_timestamp_list
        
        # 将得到的新数据，混合原始数据得到新的数据集
        inter_data = pd.read_csv(args.dataset_path + f'{args.ori_dataset}/{args.ori_dataset}.inter', delimiter='\t')
        
        new_inter_data = pd.DataFrame(new_data_dict)

        # 合并新创建的数据集
        hybrid_inter_data = pd.concat([inter_data, new_inter_data])

        # dump 新的数据集
        hybrid_inter_data.to_csv(path_or_buf=args.dataset_path + f'Hybrid_Datasets/{args.new_dataset_name}_{args.hybrid_dataset_mode}/{args.new_dataset_name}_{args.hybrid_dataset_mode}.inter', sep='\t', index=False)
        new_inter_data.to_csv(path_or_buf=args.dataset_path + f'Hybrid_Datasets/{args.new_dataset_name}_{args.hybrid_dataset_mode}/Generated_{args.new_dataset_name}_{args.hybrid_dataset_mode}.inter', sep='\t', index=False)
        logger.info('Dump Hybrid dataset to the path:' + args.dataset_path + f'Hybrid_Datasets/{args.new_dataset_name}_{args.hybrid_dataset_mode}/{args.new_dataset_name}_{args.hybrid_dataset_mode}.inter')

    elif args.mode == 'general':
        assert args.hybrid_dataset_mode in ['ori_dataset+filtered_dataset', 'ori_dataset+dataset']

        with open(args.project_base_path + f'data/{args.ori_dataset}/item_map.json','r') as file:
            item_map = json.load(file)
        with open(args.project_base_path + f'data/{args.ori_dataset}/user_map.json','r') as file:
            user_map = json.load(file)

        # 选择给定的数据集混合模式
        if args.hybrid_dataset_mode == 'ori_dataset+filtered_dataset':
            with open(args.project_base_path + f'data/{args.new_dataset_name[8:]}/JinaExtractSubInterest/jina_extract_dataset/filtered_jina_extract_dataset.json','r') as file:
                filtered_jina_extract_dataset = json.load(file)
            filtered_jina_extract_dataset_map = {k: str(v[0][0]) for k, v in filtered_jina_extract_dataset.items()}
            new_data_map = filtered_jina_extract_dataset_map
        elif args.hybrid_dataset_mode == 'ori_dataset+dataset':
            with open(args.project_base_path + f'data/{args.new_dataset_name[8:]}/JinaExtractSubInterest/jina_extract_dataset/jina_extract_dataset.json','r') as file:
                jina_extract_dataset = json.load(file)
            jina_extract_dataset_map = {k: str(v[0][0]) for k, v in jina_extract_dataset.items()}
            new_data_map = jina_extract_dataset_map
        else:
            raise NotImplementedError
    
        # 扫描每个交互记录查找对应物品，并添加到新数据集中
        inter_data = pd.read_csv(args.dataset_path + f'{args.ori_dataset}/{args.ori_dataset}.inter', delimiter='\t')

        new_add_data = []
        for index, row in tqdm(inter_data.iterrows(), desc='Construct Hybrid Dataset:'):
            if (row['user_id:token'] in user_map['token_id'].keys()) and (row['item_id:token'] in item_map['token_id'].keys()) and str(item_map['token_id'][row['item_id:token']]) in new_data_map.keys():
                new_add_data.append({'user_id:token': row['user_id:token'], 'item_id:token': item_map['id_token'][new_data_map[str(item_map['token_id'][row['item_id:token']])]], 'rating:float': 5.0, 'timestamp:float': 1736236000})
        
        new_inter_data = pd.DataFrame(new_add_data)
        hybrid_inter_data = pd.concat([inter_data, new_inter_data], ignore_index=True)

        # dump 新的数据集
        hybrid_inter_data.to_csv(path_or_buf=args.dataset_path + f'Hybrid_Datasets/{args.new_dataset_name}_{args.hybrid_dataset_mode}/{args.new_dataset_name}_{args.hybrid_dataset_mode}.inter', sep='\t', index=False)
        new_inter_data.to_csv(path_or_buf=args.dataset_path + f'Hybrid_Datasets/{args.new_dataset_name}_{args.hybrid_dataset_mode}/Generated_{args.new_dataset_name}_{args.hybrid_dataset_mode}.inter', sep='\t', index=False)
        logger.info('Dump Hybrid dataset to the path:' + args.dataset_path + f'Hybrid_Datasets/{args.new_dataset_name}_{args.hybrid_dataset_mode}/{args.new_dataset_name}_{args.hybrid_dataset_mode}.inter')

if __name__ == '__main__':
    #### 命令行参数 #### 
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', '-m', type=str, default='DuoRec', help='name of models')
    parser.add_argument('--dataset', '-d', type=str, default='Amazon_Toys_small', help='name of datasets')
    parser.add_argument('--project_base_path', type=str, default='/amax/home/zitong/Documents/DivRec/', help='default project base path')
    parser.add_argument('--llm_base_path', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/', help='default LLM base path')
    parser.add_argument('--dataset_path', type=str, default='/amax/home/zitong/Documents/All_Dataset/', help='dataset path')
    parser.add_argument('--update_datset_map', type=bool, default=True, help='is need to update datset map')
    parser.add_argument('--text_encode_model', type=str, default='jinaai/jina-embeddings-v3', help='use which model to encode the text')

    # 请求llm的设置
    parser.add_argument('--num_thread', type=int, default=16, help='the number of thread used to request llm')

    args, _ = parser.parse_known_args()
    resolve_llm_output(args)