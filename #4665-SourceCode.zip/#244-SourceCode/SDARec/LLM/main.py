### 主流程代码
from preprocess import process_meta_all
from requestGPTParallel import request_llm_parallel
from requestLlama import request_llama_parallel
from postprocess import construct_hybrid_dataset, resolve_llm_output
from utils import encode_item_corpus, construct_prompts, jina_extract_seq, jina_extract_dataset, init_logger, filter_jina_extract, mk_dirs
import argparse
from logging import getLogger

if __name__ == '__main__':
    #### 命令行参数 #### 
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', '-m', type=str, default='DuoRec', help='name of models')
    parser.add_argument('--ori_dataset', '-d', type=str, default='Amazon_Toys', help='name of datasets')
    parser.add_argument('--new_dataset_name', '-n', type=str, default='Hybrid_Amazon_Toys', help='name of datasets')
    parser.add_argument('--project_base_path', type=str, default='/amax/home/zitong/Documents/DivRec/', help='default project base path')
    parser.add_argument('--llm_base_path', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/', help='default LLM base path')
    parser.add_argument('--dataset_path', type=str, default='/amax/home/zitong/Documents/All_Dataset/', help='dataset path')
    parser.add_argument('--update_datset_map', type=str, default='False', help='is need to update datset map')
    parser.add_argument('--text_encode_model', type=str, default='jinaai/jina-embeddings-v3', help='use which model to encode the text')
    parser.add_argument('--request_LLM_api', type=str, default='True', help='whether request LLM api or request local finetuned model')
    parser.add_argument('--restart_request_llm', type=str, default='True', help='whether restart to request LLM, needs a lot of time')
    parser.add_argument('--llm_task', type=str, default='jina_extract_seq', help='llm_task')
    parser.add_argument('--mode', type=str, default='general', help='for sequential or for general')
    parser.add_argument('--deepseek_api_key', type=str, default='<YOUR API TOKEN>', help='deepseek_api_key')
    parser.add_argument('--siliconflow_api_key', type=str, default='<YOUR API TOKEN>', help='siliconflow_api_key')

    ### 构建混合数据集参数
    parser.add_argument('--construct_hybrid_dataset', type=str, default='True', help='deepseek_api_key')
    parser.add_argument('--hybrid_dataset_mode', type=str, default='ori_dataset+filtered_dataset', help='deepseek_api_key')

    ### 请求本地Llama参数
    parser.add_argument('--pretrained_model_name_or_path', type=str, default='/amax/home/zitong/Documents/LLMModels/Finetuned-Llama-3-8B-Instruct/Merged_Fintuned_Llama_8B', help='the path of Llama')
    parser.add_argument('--Llama_batch_size', type=int, default=32, help='Llamda inference batch size')
    parser.add_argument('--tokenizer_max_length', type=int, default=4096, help='Llamda inference batch size')
    parser.add_argument('--Llama_output_max_length', type=int, default=4096, help='Llama_output_max_length')
    parser.add_argument('--deepspeed_config', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/config/ds_config.json', help='deepspeed_config')

    ### 请求LLM API的参数
    parser.add_argument('--num_thread', type=int, default=4, help='the number of thread used to request llm')

    ### 日志的参数  
    parser.add_argument('--log_path', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/log/', help='the number of thread used to request llm')
    parser.add_argument('--log_state', type=str, default='info', help='the number of thread used to request llm')

    args, _ = parser.parse_known_args()

    #### 初始化日志和相关目录
    init_logger(args)
    logger = getLogger()
    mk_dirs(args)

    ###########################################################预处理阶段，只在更正数据集时运行###############################################
    #### 根据数据集，创建数据集id token映射
    # quick_start.py

    #### 是否需要更新数据集中的map信息，运行quick_start.py需要重新更新
    if args.update_datset_map == 'True':
        #### 处理物品的meta信息，获得item的meta信息
        process_meta_all(args)
        #### 各类编码器处理得到数据集中物品embedding
        encode_item_corpus(args)
        logger.info("Process Meta Data to the end!")

    ########################################################### LLM处理阶段 ###############################################
    if args.restart_request_llm == 'True':
        ### 使用Jina 抽取seq 和 dataset 二元组
        if args.llm_task == 'jina_extract_seq':
            jina_extract_seq(args)
        elif args.llm_task == 'jina_extract_dataset':
            jina_extract_dataset(args)
        else:
            raise NotImplementedError

        #### 构造prompt输入
        construct_prompts(args)

        ### 请求 LLM
        if args.request_LLM_api == 'True':
            logger.info('Start to request LLM API !')
            request_llm_parallel(args)
        else:
            logger.info('Start to request local Llama !')
            request_llama_parallel(args)
        logger.info('Request LLM to the end!')

        #### 解析LLM输出
        resolve_llm_output(args)
        logger.info('Complete resolve llm output !')

        # #### 过滤原有的二元组
        filter_jina_extract(args)

    # #### 使用生成的数据，构造新的训练数据
    if args.construct_hybrid_dataset == 'True':
        construct_hybrid_dataset(args)
        logger.info('Complete construct hybrid dataset !')
    