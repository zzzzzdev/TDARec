# 构造相关的数据目录
import os
import argparse


if __name__ == '__main__':
    #### 命令行参数 #### 
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', '-m', type=str, default='DuoRec', help='name of models')
    parser.add_argument('--ori_dataset', '-d', type=str, default='yelp', help='name of datasets')
    parser.add_argument('--new_dataset_name', '-n', type=str, default='Hybrid_yelp', help='name of datasets')
    parser.add_argument('--project_base_path', type=str, default='/amax/home/zitong/Documents/DivRec/', help='default project base path')
    parser.add_argument('--llm_base_path', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/', help='default LLM base path')
    parser.add_argument('--dataset_path', type=str, default='/amax/home/zitong/Documents/All_Dataset/', help='dataset path')
    parser.add_argument('--update_datset_map', type=str, default='False', help='is need to update datset map')
    parser.add_argument('--text_encode_model', type=str, default='jinaai/jina-embeddings-v3', help='use which model to encode the text')
    parser.add_argument('--request_LLM_api', type=str, default='True', help='whether request LLM api or request local finetuned model')
    parser.add_argument('--restart_request_llm', type=str, default='False', help='whether restart to request LLM, needs a lot of time')
    parser.add_argument('--llm_task', type=str, default='jina_extract_seq', help='llm_task')
    parser.add_argument('--deepseek_api_key', type=str, default='sk-56559d61e73249b28f8dd142f1315eeb', help='deepseek_api_key')

    ### 构建混合数据集参数
    parser.add_argument('--hybrid_dataset_mode', type=str, default='ori_dataset+filtered_seq+filtered_dataset', help='deepseek_api_key')

    ### 请求本地Llama参数
    parser.add_argument('--pretrained_model_name_or_path', type=str, default='/amax/home/zitong/Documents/LLMModels/Finetuned-Llama-3-8B-Instruct/Merged_Fintuned_Llama_8B', help='the path of Llama')
    parser.add_argument('--Llama_batch_size', type=int, default=32, help='Llamda inference batch size')
    parser.add_argument('--tokenizer_max_length', type=int, default=4096, help='Llamda inference batch size')
    parser.add_argument('--Llama_output_max_length', type=int, default=4096, help='Llama_output_max_length')
    parser.add_argument('--deepspeed_config', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/config/ds_config.json', help='deepspeed_config')

    ### 请求LLM API的参数
    parser.add_argument('--num_thread', type=int, default=16, help='the number of thread used to request llm')

    ### 日志的参数  
    parser.add_argument('--log_path', type=str, default='/amax/home/zitong/Documents/DivRec/LLM/log/', help='the number of thread used to request llm')
    parser.add_argument('--log_state', type=str, default='info', help='the number of thread used to request llm')

    args, _ = parser.parse_known_args()


    path1 = args.dataset_path + 'Hybrid_Datasets/' + args.new_dataset_name + '_' + args.hybrid_dataset_mode
    path2 = args.project_base_path + 'data/' + args.ori_dataset + '/'
    path3 = args.project_base_path + 'data/' + args.new_dataset_name + '/JinaExtractSubInterest/jina_extract_dataset/'
    path4 = args.project_base_path + 'data/' + args.new_dataset_name + '/JinaExtractSubInterest/jina_extract_seq/'
    path5 = args.llm_base_path + f'llm_response/' + args.new_dataset_name + '/jina_extract_seq/'
    path6 = args.llm_base_path + f'llm_response/' + args.new_dataset_name + '/jina_extract_dataset/'
    path7 = args.llm_base_path + 'Prompts/' + args.new_dataset_name + '/jina_extract_dataset/'
    path8 = args.llm_base_path + 'Prompts/' + args.new_dataset_name + '/jina_extract_seq/'
    path9 = args.llm_base_path + 'log/' + args.ori_dataset + '/'
    necessary_dirs_list = [path1, path2, path3, path4, path5, path6, path7, path8, path9]
    for path in necessary_dirs_list:
        if not os.path.exists(path):
            os.makedirs(path)