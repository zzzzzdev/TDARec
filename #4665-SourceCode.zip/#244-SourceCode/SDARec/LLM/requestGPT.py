import requests
import typing
import json
import pickle
import os
# os.environ['http_proxy'] = "172.18.166.31:7899"
# os.environ['https_proxy'] = os.environ['http_proxy']
os.environ['http_proxy'] = ""
os.environ['https_proxy'] = os.environ['http_proxy']

def deepseek_request_chat(api_key: str, 
                          model: str, 
                          messages: typing.List[dict], 
                          timeout: int = 100, 
                          *, 
                          max_tokens: int = 2048, 
                          stop: typing.Union[typing.List[str], None] = None, 
                          temperature: float = 1.0, 
                          top_p: float = 1.0, 
                          frequency_penalty: float = 0.0, 
                          presence_penalty: float = 0.0, 
                          n: int = 1, 
                          **kargs
                          )-> dict:
    '''
    访问deepseek平台的对话API。
    api_key: 使用的API_Key
    model: 使用的模型名称
    messages: 符合OpenAI调用格式的消息内容
    timeout: 单次网络访问最大时间限制
    max_tokens: 最大生成词元数
    stop: 停止标记，字符串列表格式
    temperature: 采样温度，取值为[0, 2.0]
    top_p: 采样概率累计，取值为(0, 1.0]
    frequency_penalty: 频率惩罚，正值会降低模型在一行中重复使用已经频繁出现的词的可能性，取值为[-2.0, 2.0]
    presence_penalty: 话题新鲜度，较高的值更可能扩展到新话题，取值为[-2.0, 2.0]
    n: 生成样本数量
    '''

    url = "https://api.deepseek.com/chat/completions"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
        }

    payload = { # 参数设置
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "stop": stop,
        "temperature": temperature,
        "top_p": top_p,
        "frequency_penalty": frequency_penalty,
        "presence_penalty": presence_penalty,
        "n": n
        }

    response = requests.request("POST", url, json=payload, headers=headers, timeout=timeout)
    if response.status_code != 200:
        response.raise_for_status()

    return response.json()

def pumpkin_request_chat(api_key: str, 
                         model: str, 
                         messages: typing.List[dict], 
                         timeout: int = 15, 
                         *, 
                         max_tokens: int = 512, 
                         stop: typing.Union[typing.List[str], None] = None, 
                         temperature: float = 1.0, 
                         top_p: float = 1.0, 
                         frequency_penalty: float = 0.0, 
                         presence_penalty: float = 0.0, 
                         n: int = 1, 
                         **kargs)-> dict:
    '''
    访问pumpkin平台的对话API。
    api_key: 使用的API_Key
    model: 使用的模型名称
    messages: 符合OpenAI调用格式的消息内容
    timeout: 单次网络访问最大时间限制
    max_tokens: 最大生成词元数
    stop: 停止标记，字符串列表格式
    temperature: 采样温度，取值为[0, 2.0]
    top_p: 采样概率累计，取值为(0, 1.0]
    frequency_penalty: 频率惩罚，正值会降低模型在一行中重复使用已经频繁出现的词的可能性，取值为[-2.0, 2.0]
    presence_penalty: 话题新鲜度，较高的值更可能扩展到新话题，取值为[-2.0, 2.0]
    n: 生成样本数量
    '''

    url = "https://api.pumpkinaigc.online/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
        }

    payload = { # 参数设置
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "stop": stop,
        "temperature": temperature,
        "top_p": top_p,
        "frequency_penalty": frequency_penalty,
        "presence_penalty": presence_penalty,
        "n": n
        }

    response = requests.request("POST", url, json=payload, headers=headers, timeout=timeout)
    if response.status_code != 200:
        response.raise_for_status()

    return response.json()

def construct_LLM_input():
    # 加载scl views信息
    with open('/amax/home/zitong/Documents/DivRec/data/Amazon_Toys_small/interaction.json', 'r') as file:
        interaction = json.load(file)
    with open('/amax/home/zitong/Documents/DivRec/data/Amazon_Toys_small/item_map.json', 'r') as file:
        item_map = json.load(file)

    target_title_list = []
    interaction_sequences_list = []
    target_seqs = interaction['target_seqs']
    for target_id, same_target_seq in target_seqs.items():
        target_title = item_map['token_attribute'][item_map['id_token'][target_id]]['title']
        interaction_sequences = [list(map(lambda x: item_map['token_attribute'][item_map['id_token'][str(x)]]['title'], seq)) for seq in same_target_seq]
        target_title_list.append(target_title)
        interaction_sequences_list.append(interaction_sequences)
    
    target_item_title = target_title_list[2]
    interaction_sequences = interaction_sequences_list[2]
    print(target_item_title)
    print(interaction_sequences)

    prompt_template = f"""
    ## Role 
    You are an expert in analyzing and capturing user preferences according to historical behaviors.

    ## Task
    Given some users <Historical Behaviors>, the items in each historical behavior are sorted in chronological order. The <Historical Behaviors> are quite different from different users, but the next target item in all <Historical Behaviors> are the same, which is '{target_item_title}'.Please help me to do the following tasks in order, and a historical behavior completes all steps before moving on to the next historical behavior.
    Step 1: Please identify the key factors and user preferences that influence the purchase of '{target_item_title}' by analyzing each historical behavior.
    Step 2: Please use world knowledge (e.g., item attributes, item title, item brand, item price and so on), key factors and user preferences in Step 1 to reason and analyze which items in each historical behavior MOST affect the final purchase of '{target_item_title}'. These items (named <relateted items>) should be arranged in in chronological order.
    Step 3: Please use world knowledge (e.g., item attributes, item title, item brand, item price and so on), preferences in Step 1 to check the <relateted items> in Step 2 whether MOST heavily affect the final purchase of '{target_item_title}'. If not, correct the <relateted items> and explain the reason.
    Step 4: Please summarize the corrected <relateted items> that MOST heavily affect the final purchase of '{target_item_title}' in [] in Step 3 for each historical behavior. DON'T contain any other token.
    
    ## Resonse Format
    You MUST do the <## Task> step by step carefully for each user. A historical behavior completes all steps before moving on to the next historical behavior.
    ### No.xx:
        **Step 1: Identify the key factors and user preferences:
        **Step 2: <related items>:
        **Step 3: Check and correct <related items>:
        **Step 4: Summarize corrected <related items>: use '@' to separate each item.

    ## Historical Behaviors\n
    """

    for i in range(len(interaction_sequences)):
        prompt_template = prompt_template + f"No.{i + 1}: {interaction_sequences[i]}\n"

    tail = """
    ## Requirements
        ###(1) The <## Historical Behaviors> only contains item title. Please use world knowledge (e.g., item attributes, item title, item brand, item price and so on) about the items to enhance the <## Task>.
        ###(2) Please do the <## Task> for each historical behavior in <## Historical Behaviors>.
        ###(3) You MUST do the <## Task> step by step carefully for each user. The response need to follow the <##Resonse Format>.
    """
    prompt_template = prompt_template + tail

    return prompt_template

def request_GPT():
    api_key = "<YOUR API KEY>" # 要使用的API-Key
    model = "gpt-4o-mini" # 模型名称
    # construct LLM input
    LLM_input = construct_LLM_input()
    messages = [ # 对话内容
            {
                "role": "user",
                "content": LLM_input,
            }
        ]

    try:
        content = pumpkin_request_chat(api_key, model, messages) # 可根据需要调整其他参数
    except requests.exceptions.Timeout:
        print("请求超时！")
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP错误: {http_err}")
    except requests.exceptions.RequestException as e:
        print(f"请求错误: {e}")
    return content

def request_DeepSeek(LLM_input):
    api_key = "<YOUR API KEY>" # 要使用的API-Key
    model = "deepseek-chat" # 模型名称
    # construct LLM input
    # LLM_input = construct_LLM_input()
    messages = [ # 对话内容
            {
                "role": "user",
                "content": LLM_input,
            }
        ]

    try:
        content = deepseek_request_chat(api_key, model, messages) # 可根据需要调整其他参数
        
    except requests.exceptions.Timeout:
        print("请求超时！")
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP错误: {http_err}")
    except requests.exceptions.RequestException as e:
        print(f"请求错误: {e}")
    return content

def print_balance_apikey():
    url = "https://api.deepseek.com/user/balance"
    api_key = "<YOUR API KEY>" # 要查询的API-Key

    headers = {
    "Accept": "application/json",
    "Authorization": f"Bearer {api_key}"
    }
    response = requests.request("GET", url, headers=headers)
    print(response.text)


if __name__ == '__main__':
    # content = request_GPT()
    with open('/amax/home/zitong/Documents/DivRec/LLM/Prompts/prompts_inputs.pkl','rb') as file:
        prompts_inputs = pickle.load(file)
    LLM_input = prompts_inputs[0][20] 

    content = request_DeepSeek(LLM_input)
    content['target_id'] = "4"
    dic = {}
    dic[content['target_id']] = [content]
    with open('/amax/home/zitong/Documents/DivRec/LLM/llm_response/once_llm_response.json', 'w') as file:
        json.dump(dic, file)
    print(LLM_input)

    

    
